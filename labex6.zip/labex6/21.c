#include <stdio.h>         
#include <stdlib.h>
#include <string.h>

int stoi(char *str)
{
    int x;
    sscanf(str, "%d", &x);
    return x;
}

typedef struct stack
{
 int data;
 struct stack* next; 
}stack;

stack* top=NULL;
int Size=0;    

void push(int key) 
{
 if(top==NULL)
 {
  top =(stack*)malloc(sizeof(stack));
  top->data=key;
 }
 else
 {
  stack *t=(stack *)malloc(sizeof(stack));
  t->next=top;
  t->data=key;
  top=t;
 }
 
 Size++;
 return;
}

int pop()       
{
 if(Size==0) return -1;
 
 int last=top->data;      
 top=top->next;
 Size--;                 
 return last;         
}

int peek()        
{
 if(Size==0) return -1;
 
 return (top->data);        
}

void print()       
{
  stack *t=(stack*)malloc(sizeof(stack));
  t=top;
    while(t)
    {
     printf("%d\n",t->data);
     t=t->next;
    }
    free(t);
  return;  
}                         

int size()
{
 return Size;        
}

int isEmpty()      
{
 if(Size==0) return 1;
 return 0;
}

int operator(char r)
{
 if(r=='+' ||r=='-' ||r=='/' ||r=='*')
 {
  return 1;
 }
 return 0;
}

int solve(int a,int b,char e)
{
 int m=a,n=b;
 if(e=='+')return (a+b);
 else if(e=='-')return (b-a);
 else if(e=='*')return (b*a);
 else if(e=='/')return (b/a);

}

int main (int argc, char **argv)
{
    char line[128];
    char v1[50];

    char ret;

    while (fgets(line, sizeof line, stdin) != NULL )
    {
        sscanf(line, "%s ", v1);
        if(!v1[0])printf("invalid\n");
        
        if(operator(v1[0]) )
        {
         int a=pop();
         int b=pop();
         if(a==-1 || b==-1){printf("invalid\n");return 0;}
         else
         {
          
          if(v1[0]=='/' && a==0)
          {
           printf("division by 0\n");
           return 0;
          }
          int j=solve(a,b,v1[0]);
          push(j);
         }
        }
        //else if(operator(v1[0]) && Size<2)printf("invalid\n");
        else 
        {
         push(stoi(v1));
        }  
    }
    if(Size!=1)printf("invalid\n");
    else printf("%d\n",top->data);
    return 0;
}
