//QUESTION 1.1 ::

#include <stdio.h>         //Including necessary header files
#include <stdlib.h>
#include <string.h>

int stoi(char *str)
{
    int x;
    sscanf(str, "%d", &x);
    return x;
}

typedef struct stack      //Defining the stack structure for linklist
{
 int data;              //structure object for containing the value
 struct stack* next;     //strucutre object for pointing the next element
}stack;

stack* top=NULL;        //defining top to be NULL in the beginning
int Size=0;    

void push(int key)       //function to push elements in the linklist stack
{
 if(top==NULL)           //checking for overflow condition
 {
  top =(stack*)malloc(sizeof(stack));     //defining top malloc for dynamic allocation of memory
  top->data=key;            //assigning value to top 
 }
 else                    //else passing the value to temporary malloc and then incrementing top
 {
  stack *t=(stack *)malloc(sizeof(stack)); //defining temprory stack
  t->next=top;           //pointing top to the next of temorary pointer
  t->data=key;             
  top=t;                //incrementing top
 }
 
 Size++;               //increasing size of stack
 return;       //time complexity=O(1)
}

int pop()                //function for poping a character from the stack, returning the deleted character
{
 if(Size==0) return -1;  //returning a fake character if underflow
 
 int last=top->data;     //storing the value to be deleted
 top=top->next;           //decrementing top, by taking it the position of its next pointer place
 Size--;                 
 return last;     //time complexity=O(1)
}

int peek()                  //returning the peek element
{
 if(Size==0) return -1;    //returning fake characrter in case of underflow
 
 return (top->data);     //time complexity=O(1)
}

void print()       //function to print the elements of stack in opposite order from inserting
{
  stack *t=(stack*)malloc(sizeof(stack));  //defining temprory stack pointer
  t=top;                                   //assigning temporary element to top
    while(t)            //iterating with complexity O(n), untill the bottom of stack is reached
    {
     printf("%c\n",t->data);
     t=t->next;          
    }
    free(t);        //vacating the extra space used
  return;      //time complexity=O(n)
}                         

int size()     //function to return the size of stack
{
 return Size;        //time complexity=O(1)
}

int isEmpty()      //function to return 1 if stack is empty, else 0
{
 if(Size==0) return 1;
 return 0;
}

int operator(char r)      //function to check whether a character given is an operator or not
{
 if(r=='+' ||r=='-' ||r=='/' ||r=='*')
 {
  return 1;              //return 1 if it is else 0
 }
 return 0;               //time complexity =O(1)
}

int solve(int a,int b,char e)   //function to solve the arithematic operation called
{
 int m=a,n=b;
 if(e=='+')return (a+b);        //returning thwe operation results
 else if(e=='-')return (b-a);   //since 'a' is popped first, the operation will be (b operator a) instead of (a operator b)
 else if(e=='*')return (b*a);
 else if(e=='/')return (b/a);   //time complexity = O(1)  
 return 0;
}

int main (int argc, char **argv)
{
    char line[128];
    char v1[50];

    while (fgets(line, sizeof line, stdin) != NULL )   //for taking input uptill it is provided
    {
        sscanf(line, "%s ", v1);                  //scanning the string out of line
        if(!v1[0])printf("invalid\n");            //returning invalid if no input is given
        
        if(operator(v1[0]))                  //condition to do operation if the operator is detected
        {
         int a=pop();                        //popping operands out of the stack
         int b=pop();
         if(a==-1 || b==-1){printf("invalid\n");return 0;} //checking if a and b exist or not 
         else
         {
          
          if(v1[0]=='/' && a==0)             //checking for division by zero error
          {
           printf("division by 0\n");
           return 0;
          }
          
          int j=solve(a,b,v1[0]);           //otherwise solving them to find the desired result
          push(j);                   //pushing the result back into the stack so as to keep continuing the process
         }
        }
        
        else 
        {
         push(stoi(v1));       //if the input is an operand, directly pushing it into the stack
        }  
    }
    if(Size!=1)printf("invalid\n"); //throwing error if stack is still having multiple values and not just one final result
    else printf("%d\n",top->data);  //otherwise printing the result
    return 0;
}



//QUESTION 2.1 ::

#include <stdio.h>         //Including necessary header files
#include <stdlib.h>
#include <string.h>

int stoi(char *str)
{
    int x;
    sscanf(str, "%d", &x);
    return x;
}

typedef struct stack      //Defining the stack structure for linklist
{
 char data;              //structure object for containing the value
 struct stack* next;     //strucutre object for pointing the next element
}stack;

stack* top=NULL;        //defining top to be NULL in the beginning
int Size=0;    

void push(char key)       //function to push elements in the linklist stack
{
 if(top==NULL)           //checking for overflow condition
 {
  top =(stack*)malloc(sizeof(stack));     //defining top malloc for dynamic allocation of memory
  top->data=key;            //assigning value to top 
 }
 else                    //else passing the value to temporary malloc and then incrementing top
 {
  stack *t=(stack *)malloc(sizeof(stack)); //defining temprory stack
  t->next=top;           //pointing top to the next of temorary pointer
  t->data=key;             
  top=t;                //incrementing top
 }
 
 Size++;               //increasing size of stack
 return;       //time complexity=O(1)
}

char pop()                //function for poping a character from the stack, returning the deleted character
{
 if(Size==0) return '1';  //returning a fake character if underflow
 
 char last=top->data;     //storing the value to be deleted
 top=top->next;           //decrementing top, by taking it the position of its next pointer place
 Size--;                 
 return last;     //time complexity=O(1)
}

char peek()                  //returning the peek element
{
 if(Size==0) return '1';    //returning fake characrter in case of underflow
 
 return (top->data);     //time complexity=O(1)
}

void print()       //function to print the elements of stack in opposite order from inserting
{
  stack *t=(stack*)malloc(sizeof(stack));  //defining temprory stack pointer
  t=top;                                   //assigning temporary element to top
    while(t)            //iterating with complexity O(n), untill the bottom of stack is reached
    {
     printf("%c\n",t->data);
     t=t->next;          
    }
    free(t);        //vacating the extra space used
  return;      //time complexity=O(n)
}                         

int size()     //function to return the size of stack
{
 return Size;        //time complexity=O(1)
}

int isEmpty()      //function to return 1 if stack is empty, else 0
{
 if(Size==0) return 1;
 return 0;
}

int operator(char r)  //function to verify whether a input is operator or not
{
 if(r=='+' ||r=='-' ||r=='/' ||r=='*' || r=='(' ||r==')')
 {
  return 1;
 }                    //time complexity =O(1)
 return 0;
}

int prec(char a)  //function to set the precision of different operators and return it on function call
{
 if(a=='/' || a=='*') return 2;
 if(a=='+' || a=='-') return 1; //returning precision
 return 0;
}

int main (int argc, char **argv)
{
    char line[128];
    char s[50];

    char* p=(char*)malloc(sizeof(char)); //creating malloc to store the values to be printed, equivalent to printing that

    fgets(line, sizeof line, stdin);   //taking input of one line
        sscanf(line, "%s", s);
        
    int i=0,j=0;
    
    while(s[i])                  //iterating unless s[i] exists
    {
     if(!operator(s[i]))         //if its an operand than putting it into malloc created
     {
      p[j]=s[i];j++;
     }
     else if(s[i]=='(')     //if its an opening parenthesis, then pushing them into the stack
     {
      push(s[i]);
     }
     else if(s[i]==')')    //if its a closing paranthesis,then printing the values until opening parenthesis is found
     {
      while(top->data!='(') //checking for '(' in the stack of operators
      {
       p[j]=pop();j++;     //placing popped values in malloc created, to be printed 
      }
      char c = pop();    //popping '('
     }
     else
     {
      while(Size!=0)       //while the stack is not empty performing operator transactions
      {
       if(peek()=='(')   //pushing the operator if if initially '(' was top element as that operator comes inside that parenthesis pair
       {
        push(s[i]);break; //pushing, getting out of loop once its done
       }
       else if(prec(s[i])>prec(top->data))  //if the new entered value is having more precedence,
       {                                    //then pushing it into stack so as to maintainthe heirarchy
        push(s[i]);break;
       }                                //breaking out of loop once done
       else if(prec(s[i])<=prec(top->data)) //checking for equal and greater cases as allowed operators are only L->R
       {                                    //precedence according to the question
        p[j]=pop();j++;            //for popping until its precedence is not greater then the top value
        continue;
       }
       else                  //popping in rest of the cases, just to deal with exception cases
       {
        p[j]=pop();j++;
        continue;
       }
      }
     
      if(Size==0)push(s[i]);  //if the stack is empty, then pushing elements into it 
     }
     i++;   
    }
    while(Size!=0)
    {                   //iteratively removing elements from stack to remove leftover operators
     p[j]=pop();j++;   
    }
    
    p[j]='\0';            //ending the malloc
    printf("%s\n",p);     //printing the dezired result
    
    free(p);             //freeing the malloc allocated
    return 0;
}
