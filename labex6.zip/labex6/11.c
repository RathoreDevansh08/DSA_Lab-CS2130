#include <stdio.h>         
#include <stdlib.h>
#include <string.h>

int stoi(char *str)
{
    int x;
    sscanf(str, "%d", &x);
    return x;
}

typedef struct stack
{
 char data;
 struct stack* next; 
}stack;

stack* top=NULL;
int Size=0;    

void push(char key) 
{
 if(top==NULL)
 {
  top =(stack*)malloc(sizeof(stack));
  top->data=key;
 }
 else
 {
  stack *t=(stack *)malloc(sizeof(stack));
  t->next=top;
  t->data=key;
  top=t;
 }
 
 Size++;
 return;
}

char pop()       
{
 if(Size==0) return 'z';
 
 char last=top->data;      
 top=top->next;
 Size--;                 
 return last;         
}

char peek()        
{
 if(Size==0) return -1;
 
 return (top->data);        
}

void print()       
{
  stack *t=(stack*)malloc(sizeof(stack));
  t=top;
    while(t)
    {
     printf("%c\n",t->data);
     t=t->next;
    }
    free(t);
  return;  
}                         

int size()
{
 return Size;        
}

int isEmpty()      
{
 if(Size==0) return 1;
 return 0;
}

int operator(char r)
{
 if(r=='+' ||r=='-' ||r=='/' ||r=='*' || r=='(' ||r==')')
 {
  return 1;
 }
 return 0;
}

int prec(char a)
{
 if(a=='/' || a=='*') return 2;
 if(a=='+' || a=='-') return 1;
 return 0;
}

int main (int argc, char **argv)
{
    char line[128];
    char s[50];

    char* p=(char*)malloc(sizeof(char));

    fgets(line, sizeof line, stdin);
        sscanf(line, "%s", s);
        
    int i=0,j=0;
    
    while(s[i])
    {
     if(!operator(s[i]))
     {
      p[j]=s[i];j++;
     }
     else if(s[i]=='(')
     {
      push(s[i]);
     }
     else if(s[i]==')')
     {
      while(top->data!='(')
      {
       p[j]=pop();j++;
      }
      char c = pop();
     }
     else{
     while(Size!=0)
     {
     
     if(peek()=='(')
      {
       push(s[i]);break;
      }
     else if(prec(s[i])>prec(top->data))
     {
      push(s[i]);break;
     }
     else if(prec(s[i])<=prec(top->data))
     {
       p[j]=pop();j++;
       continue;
     }
     else 
     {
       p[j]=pop();j++;
      continue;
     }
     }
     
     if(Size==0)push(s[i]);
     
     }
     i++;
    }
    while(Size!=0)
    {
     p[j]=pop();j++;
    }
    p[j]='\0';
    printf("%s\n",p);
    return 0;
}
