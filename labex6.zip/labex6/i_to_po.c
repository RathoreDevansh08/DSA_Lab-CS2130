#include <stdio.h>         
#include <stdlib.h>
#include <string.h>

int stoi(char *str)
{
    int x;
    sscanf(str, "%d", &x);
    return x;
}

typedef struct stack
{
 char data;
 struct stack* next; 
}stack;

stack* top=NULL;
int Size=0;    

int isOp(char a)
{
 if(a=='*' || a=='+' || a=='-' || a=='/')
 return 1;
 return 0;
}
int prec(char a)
{
 if(a=='^')return 3;
 if(a=='*' || a=='/')return 2;
 if(a=='+' || a=='-')return 1;
 return 0;
}

void push(char key) 
{
 if(top==NULL)
 {
  top =(stack*)malloc(sizeof(stack));
  top->data=key;
 }
 else
 {
  stack *t=(stack *)malloc(sizeof(stack));
  t->next=top;
  t->data=key;
  top=t;
 }
 
 Size++;
 return;
}

char pop()       
{
 if(Size==0) return '@';
 
 char last=top->data;      
 top=top->next;
 Size--;                 
 return last;         
}

char peek()        
{
 if(Size==0) return '@';
 
 return (top->data);        
}

void print()       
{
  stack *t=(stack*)malloc(sizeof(stack));
  t=top;
    while(t)
    {
     printf("%c\n",t->data);
     t=t->next;
    }
    free(t);
  return;  
}                         

int size()
{
 return Size;        
}

int isEmpty()      
{
 if(Size==0) return 1;
 return 0;
}

int main ()
{
    char line[128];
    char s[50];

    char ret;
    //int lineNo = 0;
    int i=0,j=0;
    
    fgets(line, sizeof line, stdin);
    sscanf(line,"%s", s);
    char *p=(char*)malloc(100*sizeof(char));
    
    while(s[i])
    {
     //if(isOp(s[i])){push(s[i]);i++;continue;}
     if(!isOp(s[i]))
     {
      p[j]=s[i];j++;
     }
     else if(s[i]=='(')push(s[i]);
     else if(s[i]==')')
     {
      while(top->data!='(')
      {
       char d=pop();
       p[j]=d;j++;
      }
      char d2=pop();
     }
     else 
     {
      if(Size==0 || peek()=='(')
      {
       push(s[i]);
      }
      else if(prec(s[i])>prec(top->data))
      {
       push(s[i]);
      }
      else if(prec(s[i])<prec(top->data))
      {
       while(Size!=0 && prec(s[i])<prec(top->data))
      {
       char r=pop();
       p[j]=r;j++;
      }
       push(s[i]);
      }
     else
     {
      if(s[i]!='^')
       {
        while(prec(s[i])==prec(top->data))
        {
         char e=pop();
         p[j]=e;j++;i++;
         if(Size==0)break;
        }
        push(s[i]);
       }
        else
        {
         push(s[i]);//break;
        }
       }
     }
     i++;
    }
    
    while(Size!=0)
    {
     p[j]=pop();j++;
    }
    p[j]='\0';
    printf("\n%s\n",p);
    print();
    return 0;
}
