#include<stdio.h>
#include<stdlib.h>

void max_heapify(int A[], int i, int heapSize)
{
	int temp, largest, left, right, k;

	left = ((2*i)+1);
	right = ((2*i)+2);

	if(left>heapSize)
	return;

	else
	{
	 if(left < heapSize && A[left]>A[i])
	 largest = left;

	 else
	 largest = i;

	 if(right<heapSize && A[right]>A[largest])
	 largest = right;

	 if(largest != i)
	 {
	  temp = A[i];
	  A[i] = A[largest];
	  A[largest] = temp;

	  max_heapify(A, largest, heapSize);	
	 }
		
	}
}

void build_heap(int A[], int n)
{
	int heapSize =n;
	int j;

	for(j=n/2; j>=0; j--)
	{
	 max_heapify(A, j, heapSize);
	}

	return; 
}

int extract_max(int A[], int n)
{
	int heapSize =n-1;
	int max, temp, i;

	//max=A[0];

	temp=A[0];
	A[0]=A[heapSize];
	A[heapSize]=temp;

	heapSize--;

	max_heapify(A, 0, heapSize);
	max=A[0];
	printf("Heap after extracting max: ");
	for(i=0; i<n-1; i++)
	{
	 printf("%d  ", A[i]);
	}

	printf("\n");

	return max;
}


int del_extract_max(int *p, int A[], int n)
{
	int heapSize = n;
	int max, i;

	max = A[0];
	printf("A[0]=%d\n", max);
	heapSize--;

	build_heap(p, heapSize);
	
	
	printf("Heap after deleting and extracting max: ");
	for(i=0; i<n-1; i++)
	{
	 printf("%d  ", *p);
	 p++;
	}
	
	printf("\n");
	
	printf("A[0]=%d\n", max);
	return max;
}


int main()
{
	int n, i, max;
	printf("Please enter the number of elements in the array:");
	scanf("%d", &n);

	int A[n];
	int *p, del_max;

	p = &A[1];	

	printf("Please enter the elements of the array:");
	for(i=0; i<n; i++)
	{
	 scanf("%d", &A[i]);	
	}
	
	build_heap(A, n);
	

	printf("The heap built: ");
	for(i=0; i<n; i++)
	{
	 printf("%d  ", A[i]);
	}

	printf("\n");

	printf("The maximum number in the element is %d.\n\n", A[0]);

	del_max=del_extract_max(p, A, n);

/*	for(i=0; i<n; i++)
	{

	printf("%d  ", A[i]);
 	}
*/
	printf("\n\n");
	max = extract_max(A, n);
	printf("The maximum number in the element is %d.\n\n", max);
	
	
	printf("The del_max=%d\n\n ", del_max);

	return 0;
}




