#include <stdio.h>
#include <stdlib.h>
#include <string.h>

//Code to parse integer from a string
int stoi(char *str)
{
    int x;
    sscanf(str, "%d", &x);
    return x;
}

void shift(int A[],int n)
{
    
 int j;
 for(j=0;j<n;j++)
 {
  if(A[j]<A[n-1])
  {
   break;
  }
 } 
 
 int b,t=A[j],last=A[n-1];

 A[j]=last;
 for(int h=j+1;h<n;h++)
 {
  b=A[h];
  A[h]=t;
  t=b;
 }
 
 return;

}

int main (int argc, char **argv)
{
    char line[128];
    char v1[15];
    char v2[15];
    char v3[15];

    int *A = NULL;
    int n,i;

    fgets(line, sizeof line, stdin);
    sscanf(line, "%s", v1);
    n=stoi(v1);
    A = (int*) malloc(sizeof(int)* n);
    for(i=0;i<n;i++)
    {
	fgets(line, sizeof line, stdin);
	sscanf(line, "%s", v1);
	A[i]= stoi(v1);
    }
    shift(A,n);
    
    for(int i=0;i<n;i++)
    {
     printf("%d\n",A[i]);
    }
    
    if(A)
        free(A);

    return 0;
}
