#include<stdio.h>  //importing required libraries 
#include<stdlib.h>
#include<string.h>

int size=0; //initialsing size of bst as a global variable

typedef struct node //declaring structure for the node 
{
 int data; 
 struct node *l,*r; //declaring pointer to the left and right child elements
}node;

node* createNode(int k) //function to initialize a new node
{
 node* n=(node*)malloc(sizeof(node)); //declaring it as a malloc
 n->data=k;
 n->l=n->r=NULL; //intiailising pointers to NULL
 return n;
}

node* mina(node* root) //function to return minimum element under subtree of root provided 
{
 node* t=root; 
 if(t==NULL)
 {
  printf("-1\n"); //checking for empty case
  return NULL;
 }
 while(t->l!=NULL) //iteratively reaching leftmost element 
 {
  t=t->l;
 }
 return t; //time complexity=O(height)
}

node* maxa(node* root) //function to return maximum element under subtree of root provided 
{
 node* t=root;
 if(t==NULL)
 {
  printf("-1\n"); //checking for empty case
  return NULL;
 }
 while(t->r!=NULL) //iteratively reaching rightmost element 
 {
  t=t->r;
 }
 return t; //time complexity=O(height)
}

node* insert(node* root,int k) //function for recursive insertion of a new element
{
 if(root==NULL)return createNode(k); //if you reach bottom, creating a new node
 if(k<root->data)root->l= insert(root->l,k); //inserting element to its left subtree
 else if(k>root->data)root->r = insert(root->r,k); //inserting element to its right subtree
 return root; //time complexity = O(height)
}

void post(node* root) //function to recursively print post order traversal
{
 if(root==NULL)return; //condition to end the recursion
 post(root->l);
 post(root->r);
 printf("%d ",root->data); //time complexity = O(n)
}

int search(node* root,int k) //function to recursively search for a key
{
 if(root==NULL)return -1; //returning if not found
 if(k<root->data)return search(root->l,k); //searching in left subtree
 else if(k>root->data)return search(root->r,k); //searching in right subtree
 else return 1;
}                       //time complexity = O(n)

node* delete(node* root,int k) //function to delete a particular key element
{
 if(root==NULL)return root; //checking for empty case
 if(k<root->data)root->l= delete(root->l,k); //recursively reaching the element to be deleted
 else if(k>root->data)root->r= delete(root->r,k);//& repositioning the root
 else
 {
  if(root->l==NULL) //condition for no or only right child
  {
   node* t=root->r; //replacing its right subtree to root position
   free(root); //deleting root element
   return t;
  }
  else if(root->r==NULL) //condition for only left element
  {
   node* t=root->l; //replacing its left subtree to root position
   free(root); 
   return t;
  }             //condition for two child elements
  node* s=maxa(root->l); //finding predecessor
  root->data=s->data; //replacing data
  root->l=delete(root->l,s->data); //deleting the predecessro from left subtree
 } 
 return root; //returning root of final subtree
} //worst time complexity = O(height)

int main()
{
 char line[128];
 char v1[20];int v2,h,m=0;
 node *root=NULL,*t=NULL;
 while(fgets(line,sizeof line, stdin)!=NULL)
 {
  sscanf(line,"%s %d",v1,&v2);
  if(!strcmp(v1,"MAX")) //finding maximum element of the BST
  {
   t=maxa(root);
   if(t!=NULL)printf("%d\n",t->data); //condition for failiure
  }
  if(!strcmp(v1,"MIN")) //finding minimum element of the BST
  {
   t=mina(root);
   if(t!=NULL)printf("%d\n",t->data); //condition for failiure
  }
  if(!strcmp(v1,"INS")) //inserting element in the BST
  {
   root = insert(root,v2); 
   size++; //increasing size
  }
  if(!strcmp(v1,"DEL"))
  {
   if(search(root,v2)==-1)printf("-1\n"); //deletion unsuccessful
   else{
   root=delete(root,v2); 
   if(size==0)printf("-1\n"); //underflow case
   else {size--;}} //decreasing size
  }
  if(!strcmp(v1,"PST")) //printing post order traversal
  {
   if(root==NULL)
   {
    printf("-1\n");
   }
   else
   {post(root);printf("\n");}
  }
 }
 return 0; 
}
