#include<stdio.h>
#include<stdlib.h>

int main()
{
 int p,q;
 printf("enter two integers\n");
 scanf("%d %d",&p,&q);
 
 int **ptr=(int**)malloc(p*sizeof(int*));
 
 for(int m=0;m<p;m++)
 {
  ptr[m]=(int*)malloc(q*sizeof(int));
 }
 
 for(int i=0;i<p;i++)
 {
  for(int j=0;j<q;j++)
  {
   scanf("%d",(*(ptr+i)+j));
  } 
 }
 
 for(int i=0;i<p;i++)
 {
  for(int j=0;j<q;j++)
  {
   printf("%d\t",*(*(ptr+i)+j));
  } 
  printf("\n");
 }
 
 free(ptr);
 return 0;
}
