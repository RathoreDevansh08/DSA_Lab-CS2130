#include<stdio.h> //importing important libraries

void swap(int *a,int *b) //function to swap to integers in constant time
{
 int t=*a;*a=*b;*b=t;
 return;
}

int part(int a[],int l,int r) //function to return the pivot position 
{
 int pivot=a[r]; //taking last element as the pivot
 int t=l-1; //starting from initial position
 for(int j=l;j<r;j++) //iterating and swapping btw i and r index so as to get required sorted sequence
 {
  if(a[j]<=pivot)
  {
   t++;
   swap(&a[j],&a[t]);
  }
 }
 swap(&a[r],&a[t+1]); //swapping pivot to required position
 return t+1;
}

void quick(int a[],int l,int r) //function to apply quick sort
{
 if(l>=r)return; //condition for termination
 int pivot=part(a,l,r); 
 quick(a,l,pivot-1); //recursively calling by divide and conquer method 
 quick(a,pivot+1,r);
}

int main()
{
int n;
scanf("%d",&n); //scanning the size of array
int a[n];
for(int i=0;i<n;i++)scanf("%d",&a[i]); //scanning the array
quick(a,0,n-1);
for(int i=0;i<n;i++)printf("%d ",a[i]);printf("\n"); //printing the sorted result
return 0;
}
