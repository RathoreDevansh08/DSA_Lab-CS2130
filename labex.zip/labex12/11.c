#include<stdio.h>  //importing required libraries
#include<stdlib.h>
#include<string.h>

int m; //global variable for hash table array size

int hash(int a) //hash function
{
 return a%m;
}

void add(int a[],int k) //function to insert element into the hash table
{
 int f=hash(k); //finding hash function result for a particular key
 int t=f;
 
 do //to check for empty space or if the element is already present
 {
  printf("%d(%d) ",f,a[f]); //printing the sequence of probes
  if(a[f]==k)return; //checking for initial presence
  if(a[f]<0){break;} //stopping when empty space is found (-1 or -2)
  f++; //otherwise iterating over the array
 }while(f<m);
 
 if(f==m) //if empty space is not found from t to m-1
 {        //looking for space in 0 to t-1
  f=0;
  if(t==0)return; //to ensure looping condition works fine
  do
  {
   printf("%d(%d) ",f,a[f]); //printing the sequence of probes
   if(a[f]==k)return; //checking for initial presence
  if(a[f]<0){break;} //stopping when empty space is found (-1 or -2)
  f++; //otherwise iterating over the array
  }while(f<t);
 }
 
 a[f]=k; //assigning value at stopped position
 return;
} //worst time complexity = O(m)

void search(int a[],int k) //function to search element into the hash table
{
 int f=hash(k); //finding hash function result for a particular key
 int t=f;
 do
 {
  printf("%d(%d) ",f,a[f]); //printing the sequence of probes
  if(a[f]==k || a[f]==-1)return; //terminating search if element is found or 
  f++;                           //the empty space is found indicating abscence of the value
 }while(f<m); //circular loop to initial numbers before t
 if(f==m) //if element is not found in t to m-1 
 {        //looking for it in 0 to t-1 th place
  f=0;
  if(t==0)return;
  do
  {
   printf("%d(%d) ",f,a[f]); //printing the sequence of probes
   if(a[f]==k || a[f]==-1)return; //terminating search if element is found or 
  f++;                           //the empty space is found indicating abscence of the value
  }while(f<t);
 }
 return;
} //worst time complexity = O(m)

void delete(int a[],int k) //function to find and delete element from the hash table
{
 int f=hash(k); //finding starting index
 int t=f;
 do  
 {
  printf("%d(%d) ",f,a[f]); //printing the sequence of probes
  if(a[f]==k || a[f]==-1)return; //terminating search if element is found or 
  f++;                           //the empty space is found indicating abscence of the value
 }while(f<m); //circular loop to initial numbers before t
 if(f==m) //if element is not found in t to m-1 
 {        //looking for it in 0 to t-1 th place
  f=0;
  if(t==0)return;
  do
  {
   printf("%d(%d) ",f,a[f]); //printing the sequence of probes
   if(a[f]==k || a[f]==-1)return; //terminating search if element is found or 
  f++;                           //the empty space is found indicating abscence of the value
  }while(f<t);
 }
 if(a[f]==k) //replacing the found element by -2 to indicate empty positions after delete 
 {
  a[f]=-2;
 }
 return; //worst time complexity = O(m)
}

int main()
{
 char line[128];
 char v1[20];int v2,l=-1,a[300];
 for(int i=0;i<300;i++)a[i]=-1;
 while(fgets(line,sizeof line,stdin)!=NULL)
 {
  l++;
  if(l==0)
  {
   sscanf(line,"%d",&m); //input for size fo the hash table
   continue;
  }
  sscanf(line,"%s %d",v1,&v2);
  if(!strcmp(v1,"INS")) //inserting into the hash table
  {
   add(a,v2);
   printf("\n");
  }
  else if(!strcmp(v1,"DEL")) //deleting element from the hash table
  {
   delete(a,v2);
   printf("\n");
  }
  else if(!strcmp(v1,"SRCH")) //searching the elemnt in the hash table
  {
   search(a,v2);
   printf("\n");
  }
 }
 return 0;
}
