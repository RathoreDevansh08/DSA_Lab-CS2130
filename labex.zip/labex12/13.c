#include<stdio.h> //importing the required libraries
#include<stdlib.h>

void swap(int *a,int *b) //function to swap the numbers
{
 int t=*a;*a=*b;*b=t;
 return;
}

int part(int a[],int l,int r) //function to return the pivot position 
{
 int pivot=a[r]; //taking last element as the pivot
 int t=l-1; //starting from initial position
 for(int j=l;j<r;j++) //iterating and swapping btw i and r index so as to get required sorted sequence
 {
  if(a[j]<=pivot)
  {
   t++;
   swap(&a[j],&a[t]); //swapping a and b together to maintain pair sequence
   swap(&b[j],&b[t]);
  }
 }
 swap(&a[r],&a[t+1]);
 swap(&b[r],&b[t+1]);
 return t+1;          
}

void quick(int a[],int b[],int l,int r) //function to apply quick sort algorithm
{
 if(l>=r)return; //condition for termination
 int pivot=part(a,b,l,r);
 quick(a,b,l,pivot-1);  //recursively calling by divide and conquer method 
 quick(a,b,pivot+1,r);
}

int main()
{
int n,k,l;
scanf("%d",&n);
if(n<=0)return 0;
int a[n],b[n];
for(int i=0;i<n;i++)
{
 scanf("%d %d",&a[i],&b[i]); //storing the starting and ending indices of each set
}
quick(a,b,0,n-1); //applying quick sort according to array a
k=a[0];l=b[0];
for(int i=0;i<n;i++)
{
 if(a[i]>l) //condition for disjoint set
 {
  printf("%d %d\n",k,l);
  k=a[i];l=b[i]; //printing the previous joint set part
 } 
 if(b[i]>l)l=b[i]; //condition for finding bigger ending indice of joint parts
}
printf("%d %d\n",k,l); //printing final set indices

return 0;
}
