#include<stdio.h>
#include<stdlib.h>
#include<string.h>

int stoi(char *str)
{
    int x;
    sscanf(str, "%d", &x);
    return x;
}

int a[100]={-1},b[100]={0};

typedef struct node
{
 struct node *l,*r;
 int data;
}node;

int le(int d)
{
 return 2*d;
}

int ri(int d)
{
 return 2*d+1;
}

int insert(int x,int i,char c)
{
 int r;
 if(c=='l')r=le(i);
 else r=ri(i);
 if(b[i]==0 || b[r]==1)return -1;
 b[r]=1;
 a[r]=x;
 return 1;
}

void pre(int i)
{
 if(b[i]==0)return;
 printf("%d ",a[i]);
 pre(le(i));
 pre(ri(i));
 return;
}

void in(int i)
{
 if(b[i]==0)return;
 
 in(le(i));
 printf("%d ",a[i]);
 in(ri(i));
 return;
}

void pos(int i)
{
 if(b[i]==0)return;
 
 pos(le(i));
 pos(ri(i));
 printf("%d ",a[i]);
 return;
}

void occ(int k)
{
 int c=0;
 for(int i=1;i<100;i++)
 {
  if(a[i]==k)
  c++;
 }
 printf("%d\n",c);
}

int main(int argc, char **argv)
{
char line[128];
char str[10];
char v1[15],v2[15],v3[15],c[5];
int m=-1,n=0,t;
while (fgets(line, sizeof line, stdin) != NULL )
    {
        sscanf(line, "%s %s %s %s", v1, v2, v3, c);
        m++;
        if(m==0)
        {
         a[1]=stoi(v1);b[1]=1;
        }

        if(strcmp(v1,"INS") == 0)
        {
          if(strcmp(c,"l") == 0)
            t=insert(stoi(v2),stoi(v3),'l');
          else
            t=insert(stoi(v2),stoi(v3),'r');
            
           if(t==-1)printf("-1\n"); 
        }
        else if(strcmp(v1,"PRE") == 0)
        {
            pre(1);
        }
        else if(strcmp(v1,"INO") == 0)
        {
            in(1);
        }
        else if(strcmp(v1,"PST") == 0)
        {
            pos(1);
        }
        else if(strcmp(v1,"OCC") == 0)
        {
            occ(stoi(v2));
        }
    }


return 0;
}
