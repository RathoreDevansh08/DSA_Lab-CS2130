#include<stdio.h>
#include<stdlib.h>
#include<string.h>

int stoi(char *str)
{
    int x;
    sscanf(str, "%d", &x);
    return x;
}

typedef struct node
{
 struct node *l,*r,*p;
 int data;
}node;

node* ro=NULL;int size=0;

node* createNode(int d)
{
 node * t=(node*)malloc(sizeof(node));
 t->l=NULL;
 t->r=NULL;
 t->p=NULL;
 t->data=d;
}

void insert(node* ro,int k)
{
 if(k==ro->data)
 {
     size--;return;
 }
 if(k<ro->data)
 {
  if(ro->l==NULL)
  {
   node* t=createNode(k);
   ro->l=t;
   t->p=ro;
   return;   
  }
  insert(ro->l,k);
 }
 else if(k>ro->data)
 {
  if(ro->r==NULL)
  {
   node* t=createNode(k);
   ro->r=t;
   t->p=ro;
   return;   
  }
  insert(ro->r,k);
 }
 return;
}

void in(node* ro)
{
 if(ro==NULL)return;
 in(ro->l);
 printf("%d ",ro->data);
 in(ro->r);
 return ;
}

void pre(node* ro)
{
 if(ro==NULL)return;
 printf("%d ",ro->data);
 pre(ro->l);
 pre(ro->r);
 return ;
}

void pos(node* ro)
{
 if(ro==NULL)return;
 pos(ro->l);
 pos(ro->r);
 printf("%d ",ro->data);
 return ;
}

int search(node* ro,int k)
{
 if(ro==NULL)return -1;
 if(k<ro->data)return search(ro->l,k);
 else if(k==ro->data)return 1;
 else if(k>ro->data)return search(ro->r,k);
}

node* find(node *ro,int k)
{
 if(ro==NULL)return NULL;
 if(k<ro->data)return find(ro->l,k);
 else if(k==ro->data)return ro;
 else if(k>ro->data)return find(ro->r,k);
}

node* min(node* ro)
{
 if(ro->l==NULL)return ro;
 return min(ro->l);
}

node* max(node* ro)
{
 if(ro->l==NULL)return ro;
 return max(ro->r);
}

node* delete (int k)
{
 if(size==0 )
 {
  printf("-1\n");
  return NULL;
 }   
 node* t=find(ro,k);   
 if(ro==t && size==1)
 {
  ro=NULL;size--;
  return ro;
 }
 if(search(ro,k)==-1)
 {
     printf("-1\n");
     return ro;
 }
 
 if(t->r!=NULL && t->l!=NULL)
 {
  node* s=min(t->r);
  if(t->r!=s)
  {
   if(s->r!=NULL)
   s->p->l=s->r;
   else s->p->l=NULL;
   if(s->r!=NULL)
   s->r->p=s->p;
   t->data=s->data;
  }
  else
  {
   if(s->r!=NULL)
   {s->p->r=s->r;
   s->r->p=t;}
   else s->p->r=NULL;
   t->data=s->data;
  }
 }
 else if(t->r!=NULL)
 {
  if(t->p==NULL)
   {
    ro=t->r;
    t->r->p=NULL;
   }
   else if(t->p->r==t)
   {
    t->p->r=t->r;
    t->r->p=t->p;
   }
   else if(t->p->l==t)
   {
    t->p->l=t->r;
    t->r->p=t->p;
   }
 } 
 else if(t->l!=NULL)
 {
   if(t->p==NULL)
   {
    ro=t->l;
    t->l->p=NULL;
   }
   else if(t->p->l==t)
   {
    t->p->l=t->l;
    t->l->p=t->p;
   }
   else if(t->p->r==t)
   {
    t->p->r=t->l;
    t->l->p=t->p;
   }
 }
 else if(t->p->l==t)
 {
  t->p->l=NULL;
  t->p=NULL;
 }
 else if(t->p->r==t)
 {
  t->p->r=NULL;
  t->p=NULL;
 }
 size--;
 return ro;
}

int main(int argc, char **argv)
{
char line[128];
char str[10];
char v1[15],v2[15],v3[15],c[5];
int m=-1,n=0,t;
while (fgets(line, sizeof line, stdin) != NULL )
    {
        sscanf(line, "%s %s %s %s", v1, v2, v3, c);
        m++;
        if(m==0)
        {
         ro=createNode(stoi(v2));size++;
        }
        if(strcmp(v1,"INS") == 0)
        {
           if(ro==NULL)
             {
              ro=createNode(stoi(v2));
             }
           insert(ro,stoi(v2));
           size++;
        }
        else if(strcmp(v1,"PRE") == 0)
        {
            pre(ro);printf("\n");
        }
        else if(strcmp(v1,"INO") == 0)
        {
            in(ro);printf("\n");
        }
        else if(strcmp(v1,"PST") == 0)
        {
            pos(ro);printf("\n");
        }
        else if(strcmp(v1,"DEL") == 0)
        {
            ro=delete(stoi(v2));
            //if(r==NULL)printf("-1\n");
        }
        else if(strcmp(v1,"SER") == 0)
        {
            int se=search(ro,stoi(v2));
            if(se==-1)printf("N\n");
            else printf("Y\n");
        }
    }


return 0;
}
