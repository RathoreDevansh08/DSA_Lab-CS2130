#include<stdio.h>
#include<stdlib.h>

typedef struct node
{
 int data;
 struct node *left,*right ,*p;
}node;

node* r=NULL;

node* createNode(int d)
{
 node *n=(node*)malloc(sizeof(node));
 n->left=NULL;
 n->right=NULL;
 n->p=NULL;
 n->data=d;
 return n;
}

void build(node* r,int d)
{

 if(d<=r->data)
 {
  if(r->left==NULL)
  {
   node* t=createNode(d);
   r->left=t;
   t->p=r;
   return;
  }
  build(r->left,d);
 }  
 else
 {
  if(r->right==NULL)
  {
   node* t=createNode(d);
   r->right=t;
   t->p=r;
   return;
  }
  build(r->right,d);
 } 
 return;
}

int min(node* r)
{
 if(r->left==NULL)
 return r->data;
 int a=min(r->left);
 return a;
}

int max(node* r)
{
 if(r->right==NULL)
 return r->data;
 int a=max(r->right);
 return a;
}

node* search(node* r,int d)
{
 if(r==NULL)return NULL;
 if(d==r->data)return r;
 if(d<=r->data)return search(r->left,d);
 else if(d>r->data)return search(r->right,d);
}

node* pred(node* r,int d)
{
 node *t=search(r,d);
 node* m=t->p;
 if(t->left!=NULL)
 {
  t=t->left;
  int p=max(t);
  t=search(r,p);
  return t;
 }
 else if(m->right==t)
 {
  return m;
 }
 else
 {
  while(m->left==t )
  {
   t=m;
   if(t->p==NULL)return NULL;
   m=t->p;
  }
  return m;
 }
}

node* succ(node* r,int d)
{
 node *t=search(r,d);
 node* m=t->p;
 if(t->right!=NULL)
 {
  t=t->right;
  int p=min(t);
  t=search(r,p);
  return t;
 }
 else if(m->left==t)
 {
  return m;
 }
 else
 {
  while(m->right==t)
  {
   t=m;
   if(t->p==NULL)return NULL;
   m=t->p;
  }
  return m;
 }
}

node* delete(int data)
{
 node* t=search(r,data);
 if(t->right!=NULL)
 {
  node* s=succ(t,t->data);
  if(s->p==t)
  {
   if(s->right!=NULL)
   s->p->right=s->right;
   else s->p->right=NULL;
   s->right->p=t;
   t->data=s->data;
  }
  else
  {
  if(s->right!=NULL)
   s->p->left=s->right;
   else s->p->left=NULL;
   s->right->p=s->p;
   t->data=s->data;
  }
 }
 else if(t->left!=NULL)
 {
  node* s=pred(t,t->data);
  if(s->p==t)
  {
   if(s->left!=NULL)
   s->p->left=s->left;
   else s->p->left=NULL;
   s->left->p=t;
   t->data=s->data;
  }
  else
  {
  if(s->left!=NULL)
   s->p->right=s->left;
   else s->p->right=NULL;
   s->left->p=s->p;
   t->data=s->data;
  }
 }
 else if(t->p->left==t)
 {
  t->p->left=NULL;
 }
 else
 {
  t->p->right=NULL;
 }
 return r;
}

int main()
{
 char line[128];
 int v1,v2,v3,m1=0;
 node* root;
 while(fgets(line, sizeof line, stdin)!=NULL)
 {
  sscanf(line,"%d",&v1);
  if(m1==0)
  {
   r=root=createNode(v1);
   m1++;
  }
  build(root,v1);
 }
 printf("MAX: %d\n",max(root));
 printf("MIN: %d\n",min(root));
 node *s=succ(root,1), *p=pred(root,1);
 if(s!=NULL)
 printf("Successor: %d\n",s->data);
 else printf("Successor not found\n");
 if(p!=NULL)
 printf("Predecessor: %d\n",p->data);
 else printf("Predecessor not found\n");
 node *m=search(root,75);
 if(m==NULL)printf("***Search Not Found***\n");
 else printf("***Found***\n");
 root=delete(75);
 printf("deleted:%d\n",75);
 m=search(root,75);
 if(m==NULL)printf("***Search Not Found***\n");
 else printf("***Found***\n");
 return 0;
}
