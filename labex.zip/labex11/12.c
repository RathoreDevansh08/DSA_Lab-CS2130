#include<stdio.h>  //importing libraries to be used
#include<stdlib.h>
#include<string.h>

int m; //global variable for size of hash table

typedef struct node //structure for node in the linked list format of hash table
{
 int data; //for storing the numbers
 struct node *next; //pointer to point the next element in LL
}node;

typedef struct hash //structure for hash table
{
 struct node** ll; //to store inked lists for 0<=i<=m-1
 int m; 
}hash; 

node* createNode(int k) //funtion to initialize a new node
{
 node* n=(node*)malloc(sizeof(node)); //declaring each node as a malloc
 n->data=k; //initializing the number to the node
 n->next=NULL; //declaring next to be NULL in the beginning
 return n;
}

hash* createht(int mo) //function to initialize the hash table
{
 hash* H=(hash*)malloc(sizeof(hash)); //declaring hash table as malloc
 H->ll = (node**)malloc(mo*sizeof(node*)); //initializing linked list of each index btw 0 & m-1
 H->m=mo;
 for(int i=0;i<mo;i++)
 {
  H->ll[i]=createNode(-1); //intializing each LL with -1 to indicate that the LL are initially empty
 }
 return H; 
}

int fx(int a) //function to return the hash function value for a particular key
{
 return a%m; //time complexity = O(1)
}

void add(hash* H,int k) //function to add a node to the hash table according to the hash function
{
 int f=fx(k); 
 node* t=H->ll[f]; //selecting the LL according to the hash function
 node* n=createNode(k); //creating a new node
 if(t->data==-1) //condition for that LL to be empty and replacing -1
 {
  t->data=k;
  return;
 }
 else //else when collision occurs
 {
  while(t->next!=NULL) //adding new element at the back of the LL
  	t=t->next;
  t->next=n;	
 }
 return; //expected time complexity = theta(1+alpha)
}

void print(hash* H,int k) //function to print the hash table LinkedList corresonding to kth index
{
 node* t=H->ll[k]; //extracting pointer to the kth LL
 if(t->data==-1) //checking for emptyness
 {
  printf("-1\n");
  return;
 }
 while(t!=NULL) //printing otherwise
 {
  printf("%d ",t->data);
  t=t->next;
 }
 printf("\n");
 return; //expected time complexity=theta(1+alpha)
}

int search(hash* H,int k) //function to search for a particular element
{
 node* n = H->ll[fx(k)]; //jumping to the LL according the hash function
 if(n->data==-1) //condition when the LL is empty
 {
  return -1;
 }
 while(n!=NULL) //otherwise conducting linear search over the elements of LinkedList
 {
  if(n->data==k)
  {
   return 1;
  }
  n=n->next;
 }
 return -1; //expected time complexity=theta(1+alpha)
}

void delete(hash* H,int k) //function to delete a node with key k
{
 node* n=H->ll[fx(k)]; //jumping to corrseponding LinkedList
 int t=search(H,k); //searching for presence
 if(t==-1) //returning if its absent in the hash table
 {
  printf("-1\n");
  return;
 }
 if(n->data==k && n->next!=NULL) //if the element to be deleted is found at 0th position and its next is not NULL
 {
  H->ll[fx(k)]=n->next; //pointing new LL to its next element
  return;
 }
 if(n->data==k && n->next==NULL) //if the element to be deleted is found at 0th position and its next is NULL
 {
  n->data=-1; //replacing its data with -1 to redeclare it to empty state
  return;
 }
 while(n->next->data!=k) //else searching in other positions
 {
  n=n->next;
 }
  n->next=n->next->next; //skipping the element to be deleted
 
 return;//expected time complexity = theta(1+alpha)
}

int main()
{
 char line[128];
 char v1[20];int v2,h=-1,k;
 hash* H=NULL;
 while(fgets(line,sizeof line, stdin)!=NULL)
 {
  h++;
  if(h==0)
  {
   sscanf(line,"%d",&m);
   H=createht(m);
   continue;
  }
  sscanf(line,"%s %d",v1,&v2);
 
  if(!strcmp(v1,"INS"))
  {if(m<=0){printf("-1\n");continue;} //checking for m<=0 case
   if(search(H,v2)==-1)
   	add(H,v2); //inserting into hash table
   else printf("-1\n");	//if insertion is unsuccessful
  }
  if(!strcmp(v1,"DEL"))
  {
   if(m<=0){printf("-1\n");continue;} //checking for m<=0 case
   delete(H,v2); //deleting from hash table
  }
  if(!strcmp(v1,"PRT")) //printing LL corresponding t the input index
  {
   if(m<=0){printf("-1\n");continue;} //checking for m<=0 case
   print(H,v2);
  }
  if(!strcmp(v1,"SRCH")) //searching for a particular element
  {
   if(m<=0){printf("N\n");continue;} //checking for m<=0 case
   k=search(H,v2);
   if(k==-1)printf("N\n");
   else printf("Y\n");
  }
 }
 return 0; 
}
