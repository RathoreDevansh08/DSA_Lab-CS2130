#include<stdio.h>
#include<stdlib.h>

typedef struct node
{
 int data;
 struct node* next;
}node;

node* head;int size=0;
node* t;

void add(int key)
{
 if(size==0)
 {
  head = (node *)malloc(sizeof(node));
  head->data=key;
  //t = (node *)malloc(sizeof(node));
  t=head;
  size++;
 }
 else
 {
  //node* temp = (node *)malloc(sizeof(node));
  temp->data=key;
  t->next=temp;
  t=temp;
  //free(temp);
  size++;
 }
}


void insert(int i,int key)
{
 int it=0;
 if(size==0) add(key);
 
 node* temp2 = (node *)malloc(sizeof(node));
 node* temp = (node *)malloc(sizeof(node));
 temp=head;
 temp2->data=key;
 temp2->next=NULL;
 while(it!=i)
 {
  temp=temp->next;it++;
 }
 
 temp2->next=temp->next;
 temp->next=temp2;
 
 //free(temp);free(temp2);
 size++;
}

void print()
{
 int y=size;
 node* t = (node *)malloc(sizeof(node));
 t=head;
 
 while(y--) 
 {
  printf("%d\n",t->data);
  t=t->next;
 }
 free(t); 
}

int main()
{
add(10);add(5);add(6);
insert(0,7);
print();
return 0;
}

