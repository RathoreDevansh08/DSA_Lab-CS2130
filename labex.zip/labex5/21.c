#include <stdio.h>         
#include <stdlib.h>
#include <string.h>

int stoi(char *str)
{
    int x;
    sscanf(str, "%d", &x);
    return x;
}

typedef struct stack
{
 char data;
 struct stack* next; 
}stack;

stack* top=NULL;
int Size=0;    

void push(char key) 
{
 if(top==NULL)
 {
  top =(stack*)malloc(sizeof(stack));
  top->data=key;
 }
 else
 {
  stack *t=(stack *)malloc(sizeof(stack));
  t->next=top;
  t->data=key;
  top=t;
 }
 
 Size++;
 return;
}

char pop()       
{
 if(Size==0) return '1';
 
 char last=top->data;      
 top=top->next;
 Size--;                 
 return last;         
}

char peek()        
{
 if(Size==0) return '1';
 
 return (top->data);        
}

void print()       
{
  stack *t=(stack*)malloc(sizeof(stack));
  t=top;
    while(t)
    {
     printf("%c\n",t->data);
     t=t->next;
    }
    free(t);
  return;  
}                         

int size()
{
 return Size;        
}

int isEmpty()      
{
 if(Size==0) return 1;
 return 0;
}

int main (int argc, char **argv)
{
    char line[128];
    char v1[15];
    char v2[15];
    char v3[15];

    char ret;
    int lineNo = 0;

    while (fgets(line, sizeof line, stdin) != NULL )
    {
        sscanf(line, "%s %s %s", v1, v2, v3);
        lineNo++;

        if(strcmp(v1,"PSH") == 0)
        {
            push(v2[0]);
        }
        else if(strcmp(v1,"POP") == 0)
        {
            ret = pop();
            if(ret=='1')
            printf("%d\n",-1);
            else
            printf("%c\n",ret);
        }
        else if(strcmp(v1,"TOP") == 0)
        {
            ret = peek();
            if(ret =='1')
                printf("%d\n", -1);
            else    
            printf("%c\n",ret);    
        }
        else if(strcmp(v1,"PRT") == 0)
        {
            print();
        }
        else if(strcmp(v1,"SZE") == 0)
        {
            ret = size();
            printf("%d\n",ret);
        }
        else if(strcmp(v1,"EMP") == 0)
        {
            ret = isEmpty();
            printf("%d\n",ret);
        }
        else
        {
            printf("INVALID\n");
        }
    }

    return 0;
}
