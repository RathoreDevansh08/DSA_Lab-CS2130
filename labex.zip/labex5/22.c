#include <stdio.h>       
#include <stdlib.h>
#include <string.h>

int stoi(char *str)
{
    int x;
    sscanf(str, "%d", &x);
    return x;
}

typedef struct stack
{
 char data;
 struct stack* next; 
}stack;

stack* top=NULL;
int Size=0;    

void push(char key) 
{
 if(top==NULL)
 {
  top =(stack*)malloc(sizeof(stack));
  top->data=key;
 }
 else
 {
  stack *t=(stack *)malloc(sizeof(stack));
  t->next=top;
  t->data=key;
  top=t;
 }
 
 Size++;
 return;
}

void pop()       
{
 char last=top->data;      
 top=top->next;
 Size--;                        
}

int main (int argc, char **argv)
{
    char line[128];
    char v1[15];
    char v2[15];
    char v3[15];

    char ret;
    int i=0;

    fgets(line, sizeof line, stdin) != NULL ;
    
    sscanf(line, "%s", v1);
    
    while(v1[i])               //iterating on the expression elements
    {
     if(v1[i]=='(' || v1[i]=='[' || v1[i]=='{')  //checking if the expression element is an opening element
     {
      push(v1[i]);            //pushing it into the stack if its an opening element
     }
     else if(v1[i]==')')      //checking for closing brackets now
     {
      if(Size>0 && top->data=='(') pop();  //checking for atleast one element left in stack and whether its a pair
      else {printf("%d\n",0);return 0;}
     }
     else if(v1[i]=='}')
     {
      if(Size>0 && top->data=='{') pop();
      else {printf("%d\n",0);return 0;}
     }
     else if(v1[i]==']')
     {
      if(Size>0 && top->data=='[') pop();
      else {printf("%d\n",0);return 0;}
     }
    
     i++;
    }
    if(Size!=0){printf("%d\n",0);return 0;}
    printf("%d\n",1);

    return 0;
}
