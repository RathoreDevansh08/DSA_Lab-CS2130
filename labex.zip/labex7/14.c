#include<stdio.h>     //importing important libraries
#include<string.h>
#include<stdlib.h>

typedef struct node  //structure for basic node or element of a adjecency linked list
{
 int data;           //the vertex value as the data
 struct node *next;
}node;

typedef struct Graph  //structure for basic graph
{
 int nv;          //object to store Number of Vertices
 int *par,*vis,*sti,*fti,*cyc; //*par: parent index, *vis: visiterd or not, *sti & vti: starting & ending time, *cyc: to check for cyclic or not
node **ll;      //to store linked list
}Graph;

Graph *graph;

node* createNode(int ver) //function to create a new node
{
 node *newNode=(node*)malloc(sizeof(node)); //declaring new node, a malloc
 newNode->next=NULL; //initializing next pointer to null
 newNode->data=ver;
 return newNode;    
}

Graph* createGraph(int h) //funcion to create a new graph
{
 Graph* temp = (Graph*)malloc(sizeof(Graph)); //initialising it with malloc and typecasting to Graph*
 temp->ll=(node**)malloc(h*sizeof(node*)); //initialising linkedlist with size of #v *sizeof(node*)
 temp->vis= (int*)malloc(h*sizeof(int));  //initialising visited with size of #v *sizeof(int)
 temp->par= (int*)malloc(h*sizeof(int));  //initialising parent with size of #v *sizeof(int)
 temp->sti= (int*)malloc(h*sizeof(int));//initialising starting time with size of #v *sizeof(int)
 temp->fti= (int*)malloc(h*sizeof(int));//initialising ending time with size of #v *sizeof(int)
 temp->cyc= (int*)malloc(h*sizeof(int));  //initialising cycle with size of #v *sizeof(int)
 temp->nv=h;
 for(int i=0;i<h;i++) //loop to initialize the value of each object
 {
  temp->ll[i]=createNode(i); //initializing each first node to the data vertex
  temp->vis[i]=0; //intialising vertex to be not visited
  temp->par[i]=-1; //initialising parens to be none
  temp->sti[i]=0; //intialising starting and ending time to zero
  temp->fti[i]=0; //intialising starting and ending time to zero
  temp->cyc[i]=0; //intialising cyc to zero
 }
 return temp; //time complexity=O(nv)
}

void addEdge(Graph* graph,int u,int v) //function to add edge to graph/adjlist
{
 node* t =createNode(v); //making a new node
 node* temp = graph->ll[u]; //intitiallising temp node to uth linkedlist
 while(temp->next!=NULL && temp->next->data<v)//iterating to find place in list according to index
 {
  temp=temp->next;
 }
 if(temp->next!=NULL) //placing new node in between the previous list
 {t->next=temp->next;}

 temp->next=t;  //worst time complexity=O(nv)
}

int timen=1,cycle=0;

void explore(Graph* graph,int u) //function to explore each link from u
{
 graph->vis[u]=1; //making u as visited
 node *temp=graph->ll[u]; //intialising temp to uth linkedlist
 
 graph->cyc[u]=1; //putting 1 to show that it can be part of cycle
 graph->sti[u]=timen;timen++;//setting starting time
 
 while(temp->next!=NULL) //while it reaches each of u's connections
 {
 	graph->cyc[u]=1; //putting 1 to show that it can be part of cycle
 	temp=temp->next;
	if(graph->cyc[temp->data]==1)//if it had a possibility to be in cycle
		cycle=1; //then, cycle found due to cyclic loop formed
  if(graph->vis[temp->data]==0) //if not visited, exploring the vth vertex
  {
   graph->par[temp->data]=u; //declaring u as parent of v
   explore(graph,temp->data); //exploring v
  }
   for(int i=0;i<graph->nv;i++)//iterating on value to redeclare all cyclic values to zero
	{
		graph->cyc[i]=0;
    }
 }   
    graph->fti[u]=timen;timen++; //setting ending time of vertex u
}  //worst time complexity=O(n^2)

void dfs(Graph *graph) //function to run dfs
{
 for(int i=0;i<graph->nv;i++) //ierating over all the vertices
 {
  if(graph->vis[i]==0) //checking if its already visited or not
  {
   explore(graph,i);//exploring vertex
  }
 }   //time complexity =O(m+n)
}

int main()
{
 char line[128];
 
 int v1,v2;
 int n,m=-1;
 int j;
 
 Graph *graph;    
 while(fgets(line, sizeof line, stdin)!=NULL)
 {
  m++;
  if(m==0)
  {
   sscanf(line,"%d",&v1);
   n=v1;
   graph=createGraph(v1);
   continue;
  }else{
  sscanf(line,"%d %d",&v1,&v2);
  addEdge(graph,v1,v2);
 }}
 dfs(graph); //dfs function call
 
 int t,ar[n]; //initialising an array to store vertices according to their finish time
 if(cycle==1) //if found a cycle
 {
  printf("-1\n");
 }
 else  //if no cycle present i.e. acyclic
 {
  for(int i=0;i<n;i++) //initialising ar to indices
 	ar[i]=i;
  for(int i=0;i<n;i++)
  {
   for(int j=i+1;j<n;j++)
   {
    if(graph->fti[i]<graph->fti[j]) //swapping the indices and its time values if not in decreasing order
    {
     t=graph->fti[i];
     graph->fti[i]=graph->fti[j];
     graph->fti[j]=t;
     t=ar[i];
     ar[i]=ar[j];
     ar[j]=t;
    }
   }
  }
  int i;
  for(i=0;i<n;i++)  //printing the indices in decreasing order of their finish time
  	printf("%d ",ar[i]);
  	printf("\n",ar[i]);
 }
 
return 0;
}
