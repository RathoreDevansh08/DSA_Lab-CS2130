#include<stdio.h>     //importing important libraries
#include<string.h>
#include<stdlib.h>

typedef struct node  //structure for basic node or element of a adjecency linked list
{
 int data;           //the vertex value as the data
 struct node *next;
}node;

typedef struct Graph  //structure for basic graph
{
 int nv;          //object to store Number of Vertices
 int *par,*vis;  //*par for storing parent index and * vis to store whether visiterd or not
 node **ll;      //to store linked list
}Graph;

Graph *graph;

node* createNode(int ver) //function to create a new node
{
 node *newNode=(node*)malloc(sizeof(node)); //declaring new node, a malloc
 newNode->next=NULL; //initializing next pointer to null
 newNode->data=ver;
 return newNode;    
}

Graph* createGraph(int h) //funcion to create a new graph
{
 Graph* temp = (Graph*)malloc(sizeof(Graph)); //initialising it with malloc and typecasting to Graph*
 temp->ll=(node**)malloc(h*sizeof(node*)); //initialising linkedlist with size of #v *sizeof(node*)
 temp->vis= (int*)malloc(h*sizeof(int));  //initialising visited with size of #v *sizeof(int)
 temp->par= (int*)malloc(h*sizeof(int));  //initialising parent with size of #v *sizeof(int)
 
 for(int i=0;i<h;i++) //loop to initialize the value of each object
 {
  temp->ll[i]=createNode(i); //initializing each first node to the data vertex
  temp->vis[i]=0; //intialising vertex to be not visited
  temp->par[i]=-1; //initialising parens to be none
 }
 return temp; //time complexity=O(nv)
}

void addEdge(Graph* graph,int u,int v) //function to add edge to graph/adjlist
{
 node* t =createNode(v); //making a new node
 node* temp = graph->ll[u]; //intitiallising temp node to uth linkedlist
 while(temp->next!=NULL && temp->next->data<v)//iterating to find place in list according to index
 {
  temp=temp->next;
 }
 if(temp->next!=NULL) //placing new node in between the previous list
 {t->next=temp->next;}

 temp->next=t;  //worst time complexity=O(nv)
}


int main()
{
 char line[128];
 
 int v1,v2;
 int n,m=-1;
 
 while(fgets(line, sizeof line, stdin)!=NULL)  //taking input iteratively 
 {
  m++;
  if(m==0)
  {
   sscanf(line,"%d",&v1); //scanning #vertices
   n=v1;
   graph=createGraph(v1); //creating graph
   continue;
  }
  sscanf(line,"%d %d",&v1,&v2); //scanning the edges
  addEdge(graph,v1,v2);
 }
 for(int i=0;i<n;i++) //looping over all the vertices linkedlist
 {
  node* temp = graph->ll[i];
  if(temp->next==NULL){printf("$\n");continue;} //if vertex goes to no other vertex
  do
  {
   temp=temp->next;
   printf("%d$",temp->data); //printing the connections in directed graph
   
  }while(temp->next!=NULL);
  printf("\n");
 }
return 0;
}
