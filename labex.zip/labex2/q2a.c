#include<stdio.h>
#include<stdlib.h>

void rearrange(int A[],int i,int j,int ni,int nj,int no)
{
 int m=0,n=0,r[ni+nj+2],s=0; 
 while(n<=nj || m<=ni)
 {
  if(A[i+m]>=A[j+n])
  {
   r[s]=A[j+n];
   s++;n++;
  }
  else if(A[i+m]<A[j+n])
  {
   r[s]=A[i+m];
   s++;m++;
  }
 }
  while(m!=ni)
  {r[s]=A[i+m];s++;m++;}
 
 while(n!=nj)
 {r[s]=A[j+n];s++;n++;}
 
 for(int q=i;q<=i+ni;q++)
 {
  A[q]=r[q-i];
 }
 for(int q=j;q<=j+nj;q++)
 {
  A[q]=r[ni+q-j+1];
 }
 printf("rearranged:\n");
 for(int h=0;h<no;h++)
 {
  printf("%d\n",A[h]);
 }
 
 return;
}
 

int main()
{
 int ni,nj,A[500],i,j,n;
 printf("enter the number of elements for two arrays:\n");
 scanf("%d %d %d %d %d",&n,&ni,&nj,&i,&j);
 for(int k=0;k<n;k++)
 {
  scanf("%d",&A[k]);
 }

 rearrange(A,i,j,ni,nj,n);
 return 0;
}
