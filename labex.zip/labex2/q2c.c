#include<stdio.h>
#include<stdlib.h>

int main()
{
 int n,A[1000];
 printf("enter the number of elements for two arrays:\n");
 scanf("%d",&n);
 for(int y=0;y<n;y++)
 {
  scanf("%d",&A[y]);
 }
}

