#include<stdio.h>

int main()
{
 int a[]={2,7,5,8,9,1,4,3,0,6},mini,mink;
 for(int i=0;i<=9;i++)
 {
 mini=i;mink=a[i];
  for(int j=i+1;j<10;j++)
  {
   if(a[j]<mink)
   {
    mini=j;mink=a[j];
    a[j]=a[i];a[i]=mink;
   }
  }
 }
 for(int m=0;m<10;m++)
 printf("%d\n",a[m]);
 return 0;
}

