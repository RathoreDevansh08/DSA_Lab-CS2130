#include<stdio.h>

void swap(int &a,int &b)
{
 a=a+b;
 b=a-b;
 b=a-b;
}
int main()
{
 int a[]={2,7,5,8,9,1,4,3,0,6};
 for(int i=0;i<=9;i++)
 {
  for(int j=0;j<=i;j++)
  {
   if(a[i]<a[j])
   {
    swap(&a[i],&a[j]);
   }
  }
 }
 for(int m=0;m<10;m++)
 printf("%d\n",a[m]);
 return 0;
}
