#include<stdio.h>
#include<stdlib.h>

int findPivotPosition(int A[], int n)
{
 int c=0;
 for(int t=0;t<n;t++)
 {
  if(A[t]<=A[0])
  {
   c++;
  }
 }
 return c-1;
}
int main()
{
 int n,A[500];
 printf("enter the number of elements in array:\n");
 scanf("%d",&n);
 printf("enter the array:\n");
 for(int t=0;t<n;t++)
 {
  scanf("%d",&A[t]);
 }
 
 int c=findPivotPosition(A,n);
 printf("required j value:%d\n",c);
 return 0;
}
