#include <stdio.h>         //include all important libraries 
#include <stdlib.h>
#include <string.h>

//Code to parse integer from a string
int stoi(char *str)
{
    int x;
    sscanf(str, "%d", &x);
    return x;
}

int heapSize=0,total;  //initialize variables heapSize ( to store heap size), total ( to store maximum permissible size )

int parent(int i)      //function to return the index of parent element
{
    /* Fill in */
    if(i%2==0)      
    {
     return i/2-1;    
    }
    else
    {
     return i/2;
    } 
}

int left(int i)      //function to return the index of left child element
{
    /* Fill in */
    return 2*i+1;
}

int right(int i)    //function to return the index of right child element
{
    /* Fill in */
    return 2*i+2;
}

void swap(int *x, int *y)   //swapping the variables, using the pointers
{
    /* Fill in */
    int t=*x;
    *x=*y;
    *y=t;
    return;
}


void maxHeapify(int A[],int i)  //function to recursively maintain the minHeap properties by swapping the 
                                //wherever required and then shifting index to the swapped element
{
    /* Ensure that the subtree rooted at A[i] is a min heap. */
    int max=i,id=i;
    if(left(i)<heapSize && A[left(i)]>A[i])  //to check if the element is valid, and is greater than the parent element
    {
     max=left(i);             //storing the index of left child element if the conditions satisfy
    }
    else if(right(i)<heapSize && A[right(i)]>A[i]) //if left child is not 
    {
     max=right(i);            //storing the index of right child element if the conditions satisfy
    }
    
    if(max==i) return;       //returning if the value doesn't change
    swap(A+i,A+max);         //swapping to maintain maxheap property at index i position
    maxHeapify(A,max);       //recursive call
    return;                  //time complexity: O(log(n)), and constant space complexity
}

void buildHeap (int A[])     //to maintain property of maxheap
{
 int n=heapSize;             
 for(int i=n/2-1;i>=0;i--)   //iterative calling of maxheapify for all parent nodes
 {
  maxHeapify(A,i);
 }                           //time complexity:O(n), constant space complexity
}

int insertKey(int A[], int key)
{
    /* Insert the element key into the heap represented by A.
    Return 1 if the operation is successful and -1 otherwise. */
    if(heapSize==total) return -1; //checking if the heap is full
    heapSize++;                    //else increasing the heapSize
    A[heapSize-1]=key;             //inserting element at the last position
    buildHeap(A);                  //reconstructing heap
    return 1;                   //O(n) time complexity due to buildHeap function call  
}



int increaseKey(int A[], int i, int newVal)  //function to increase the value of node to newVal if lesser than that
{
    /* Decrease the value of A[i] to newVal. Return 1 if the
    operation is successful and -1 otherwise. */
    if(i>heapSize || A[i]>newVal)return -1;  //to check if its valid
    A[i]=newVal;
    buildHeap(A);           //buildHeap function call to ensure that properties of maxheap are restored
    return 1;              //time complexity = O(n) due to buildHeap function call
}


int extractMax(int A[])     //function to remove the maximum element from the heap, reconstruct heap and then return the delelted element
{
    /* Delete the root of the max heap represented by A. Return
    the deleted element if the operation is successful and -1
    otherwise. */
    if(heapSize==0) return -1;  //checking if there is atleast one element in heap
    int max=A[0];
    swap(&A[0],&A[heapSize-1]);  //swaping last element with A[0] 
    heapSize--;                 //decreasing heapSize and hence deleting the previous A[0] element
    maxHeapify(A,0);         //to reconstruct the heap
    return max;            //time complexity = O(log(n)), constant space complexity
}

void print(int A[])         //printing the elements of heap in increasing index order
{
    /* Display the heap represented by A in the increasing order
    of their indices, one element per line.*/
    int n=heapSize;
    for(int i=0;i<n;i++)
    {
     printf("%d\n",A[i]);
    }                          //time complexity = O(n)
}

int main (int argc, char **argv)
{
    char line[128];
    char v1[15];
    char v2[15];
    char v3[15];

    int *A = NULL;
    int ret;
    int lineNo = 0;

    while (fgets(line, sizeof line, stdin) != NULL )
    {
        sscanf(line, "%s %s %s", v1, v2, v3);
        lineNo++;

        if(lineNo == 1)
        {
            A = (int*) malloc(sizeof(int)* stoi(v1));
            total=stoi(v1);
            continue;
        }

        if(strcmp(v1,"INS") == 0)
        {
            ret = insertKey(A, stoi(v2));
            if(ret < 0)
                printf("%d\n", -1);
        }
        else if(strcmp(v1,"EXT") == 0)
        {
            ret = extractMax(A);
            printf("%d\n", ret);
        }
        else if(strcmp(v1,"PRT") == 0)
        {
            print(A);
        }
        else if(strcmp(v1,"INC") == 0)
        {
            ret = increaseKey(A, stoi(v2), stoi(v3));
            if(ret < 0)
                printf("%d\n", -1);
        }
        else
        {
            printf("INVALID\n");
        }
    }

    if(A)
        free(A);

    return 0;
}
