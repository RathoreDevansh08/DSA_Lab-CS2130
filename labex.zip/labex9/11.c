#include<stdio.h>
#include<stdlib.h>
#include<string.h>   //importing important libraries

int Size=0;  //initializing size of queue as a global variable
typedef struct node //defining a structure for graph node
{
 int data;
 struct node *next;
}node;

typedef struct qnode //defining a structure for queue node
{
 int data;
 struct qnode *next;
}qnode;

typedef struct graph //defining a structure for graph 
{
 int *vis,*dis,*par;
 node **ll;
 int nv;
}graph;

typedef struct queue //defining a structure for queue
{
 qnode *front,*end; //pointers for pointing front and end
}queue;

node* createNode(int k) //function to initialize a graph node and return it
{
 node* t=(node*)malloc(sizeof(node)); //declaring a malloc element for graph node
 t->next=NULL;
 t->data=k;
 return t;
}

qnode* createQnode(int k) //function to initialize a queue node and return it
{
 qnode* t=(qnode*)malloc(sizeof(qnode)); //declaring a malloc element for queue node
 t->next=NULL;
 t->data=k;
 return t;
}

queue* createQueue() //function to initialize a queue and return it
{
 queue* q=(queue*)malloc(sizeof(queue));//declaring a malloc element for queue
 q->front=q->end=NULL; //pointing front and end to NULL in the beginning
 return q;
}

graph* createGraph(int h) //funcion to create a new graph
{
 graph* G=(graph*)malloc(sizeof(graph)); //initialising it with malloc and typecasting to Graph*
 G->ll=(node**)malloc(h*sizeof(node*)); //initialising linkedlist with size of #v *sizeof(node*)
 G->vis=(int*)malloc(h*sizeof(int)); //initialising visited with size of #v *sizeof(int)
 G->dis=(int*)malloc(h*sizeof(int)); //initialising distance with size of #v *sizeof(int)
 G->par=(int*)malloc(h*sizeof(int)); //initialising parent with size of #v *sizeof(int)
 G->nv=h;
 for(int i=0;i<h;i++) //loop to initialize the value of each object
 {
  G->ll[i]=createNode(i); //initializing each first node to the data vertex
  G->vis[i]=0; //intialising vertex to be not visited
  G->dis[i]=-1; //initialising distance to be none
  G->par[i]=0; //initialising parents to be none
 }
 return G; //time complexity=O(nv)
}

void enqueue(queue *q,int k) //function to enter elements in the queue
{
 qnode* t=createQnode(k); //creating a new queue node
 if(Size==0) //if queue is empty
 {
  q->end=t;
  t->next=q->end; //declaring new element as front as well as end element
  q->front=q->end;
  Size++;         //increasing size
  return;
 }
 q->end->next=t; //adding it to the next of end pointer
 q->end=t; //changing end pointer
 Size++;
 return;
}

int dequeue(queue* q) //function to delete an element from the queue and returning its value
{
if(Size==0) //underflow condition
 {
  return -1;
 }
 int d=q->front->data; //saving value
 qnode *m=q->front;
 q->front=q->front->next; //moving front to its next
 Size--;  //decreasing size
 free(m);
 return d;
}

void addEdge(graph *G,int u,int v) //function to add edge to graph/adjlist
{
 node* temp=G->ll[u]; //intitiallising temp node to uth linkedlist
 node* t =createNode(v); //making a new node
 while(temp->next!=NULL && temp->next->data<v) //iterating to find place in list according to index
 {
  temp=temp->next;
 } 
 if(temp->next!=NULL) //placing new node in between the previous list
 {
  t->next=temp->next;
 }
 temp->next=t; //worst time complexity=O(nv)
}

void bfs(graph *G,int x) //function for breadth first search
{
 queue* q=createQueue(); //creating a new queue for index x
 enqueue(q,x);  //insertinf the vertex itself in the queue
 G->dis[x]=0; //making distance of x to x zero
 while(Size!=0) //iterating until queue becomes empty
 {
  int u=dequeue(q); //removing first element from queue
   node *temp=G->ll[u]; //assigning *temp to linkedlist of uth vertex
  while(temp->next!=NULL) //going to all its connections
  {
   temp=temp->next;
   if(G->dis[temp->data]==-1) //if not visited condition so as to ensure that vertex is its decendent
   {
    enqueue(q,temp->data); //adding element into the queue
    G->dis[temp->data]=G->dis[u]+1; //distance equation
   }
  }
 }  //worst time complexity = O(n)
}

int main()
{
 int v1,v2,v3;
 char line[128];
 int m=-1,n,k,s;
 
 graph *G; //declaring a graph G
 while(fgets(line,sizeof line,stdin)!=NULL)
 {
  m++;
  if(m==0)
  {
   sscanf(line,"%d",&v1);
   n=v1;
   G=createGraph(n); //creating/initializing graph G
   continue;
  }
  if(m==1)
  {
   sscanf(line,"%d",&v1);
   s=v1;
   continue;
  }
  if(m==2)
  {
   sscanf(line,"%d",&v1);
   k=v1;
   continue;
  }
  sscanf(line,"%d %d",&v1,&v2);
  addEdge(G,v1,v2); //adding edges to graph G 
  addEdge(G,v2,v1); //adding reverse edges to graph G so as to ensure back neighbours
 }
 bfs(G,s); //bfs for vertex s
 for(int i=0;i<n;i++)
 {
  if(G->dis[i]!=-1 && G->dis[i]<=k)printf("%d ",i); //printing according to the conditions
 }
 printf("\n");
 return 0;
}

