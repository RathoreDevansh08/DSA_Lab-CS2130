#include<stdio.h>
#include<stdlib.h>
#include<string.h>   //importing important libraries

int Size=0;  //initializing size of queue as a global variable
typedef struct node //defining a structure for graph node
{
 int data;
 struct node *next;
}node;

typedef struct stack //structure for storing expressions in stack
{
 node* data; //for storing node as data
 struct stack *next; 
}stack;

stack *top=NULL;

node* createNode(int k) //function to initialize a graph node and return it
{
 node* t=(node*)malloc(sizeof(node)); //declaring a malloc element for graph node
 t->left=NULL;  //declaring left child as null in the beginning
 t->right=NULL; //declaring right child node as null in the beginning
 t->data=k;
 return t;
}

void push(node* a) //function for inserting elements in the stack
{
 if(Size==0) //condition for beginning
 {
  top=(stack*)malloc(sizeof(stack)); //initialising top pointer
  top->data=a;
  top->next=NULL; //declaring next of top as null in the beginning
 }
 else
 {
  stack* t=(stack*)malloc(sizeof(stack)); 
  t->data=a;
  t->next=top; //assigning new pointer's next as top
  top=t; //shifting top pointer
 }
 Size++; //time complexity= O(1)
}

node* pop() //function for deleting the elements from the stack
{
 if(Size<=0)return NULL; //underflow condition
 node* d= top->data; //saving the value to be deleted
 top=top->next; //shifting top to its next
 Size--; //decreasing size
 return d;
} //time complexity= O(1)

int isOprt(char d) //function to check whether a character is an operator or not
{
 if(d=='*' || d=='+' ||d=='-'||d=='/')return 1;
 else return 0;
}

void in(node *a) //function to find & print the inorder traversal sequence
{
 if(a==NULL)return; //terminating condition 
 in(a->left); //recursive call to its left child node
 printf("%c",a->data); //printing the value
 in(a->right); //recursive call to the right child value
 return;
} //time complexity= O(n)

int main()
{
 char line[128];
 int i=0,n;
 char s[200];
 while(fgets(line,sizeof line,stdin)!=NULL) //taking the string input
 { sscanf(line,"%s",s);}
 
while(s[i]) //iterating over each element of the string input
{
 node* t=createNode(s[i]); //creating a new node for each of the string character
  if(!isOprt(s[i])) //if it is operand, then pushing it into the stack
  {
   push(t);
  }
  else //condition for operators
  {
   node* a=pop(); //popping out the last two expressions
   node* b=pop();
   t->left=b;t->right=a; //assigning them as child nodes in the tree
   push(t); //pushing the new root of subgraph back into the stack
  }
  i++;
}

node* w=pop(); //poping out the last value in stack which is the root node of tree
in(w);  //inorder traversal function call
 
 return 0;
}
