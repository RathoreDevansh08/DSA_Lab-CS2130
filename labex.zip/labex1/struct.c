#include<stdio.h>
#include<math.h>

struct qwerty
{
 int x,y;
};
int q(struct qwerty e1,struct qwerty e2)
 {
  int r1=e1.x-e2.x;int r2=e1.y-e2.y;
  int m=pow(pow(r1,2)+pow(r2,2),1/2);
  int a=(r1/m*r2/m);
  return a;
 }
 

int main()
{
 struct qwerty n1={.x=3, .y=4};
 struct qwerty n2={.x=6, .y=8};
 struct qwerty n3={.x=9, .y=12};  
 int a1=q(n1,n2),a2=q(n3,n2);
 if(a1==a2) printf("collinear\n");
 else printf("non-collinear\n");
 return 0;
}
