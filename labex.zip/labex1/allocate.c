#include<stdio.h>
#include<stdlib.h>

int main()
{
 int p,q;
 printf("enter two positive integers:\n");
 scanf("%d %d",&p,&q);
 int *ptr=(int*)malloc(p*q*sizeof(int*));
 for(int i=0;i<p*q;i++)
 {
  scanf("%d",(ptr+i));
  printf("%p\n",ptr+i);
 }
 free(ptr);
 return 0;
}
