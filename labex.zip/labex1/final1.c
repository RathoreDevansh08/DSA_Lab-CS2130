#include<stdio.h>
#include<stdlib.h>

void transpose(int p,int q,int** ptr)
{
 printf("transpose of initial matrix M:\n");
 for(int i=0;i<q;i++)
 {
  for(int j=0;j<p;j++)
  {
   printf("%d\t",ptr[j][i]);
  } 
  printf("\n");
 }
}

int** change_dimension(int p,int q,int x,int y,int** ptr)
{
 for(int i=0;i<(p);i++)
 {
  for(int j=q;j<(q+y);j++)
  {
   scanf("%d",(*(ptr+i)+j));
  } 
 }
 for(int i=p;i<(p+x);i++)
 {
  for(int j=0;j<(q+y);j++)
  {
   scanf("%d",(*(ptr+i)+j));
  } 
 }
 return ptr;
}
int main()
{
 int p,q,x,y,sum=0;
 //taking input, p & q
 printf("enter two integers\n");
 scanf("%d %d",&p,&q);
 
 //alloting pointer for p*q elements in 2D
 int **ptr=(int**)malloc(p*sizeof(int*));
 
 for(int m=0;m<p;m++)
 {
  ptr[m]=(int*)malloc(q*sizeof(int));
 }
 
 //first input
 for(int i=0;i<p;i++)
 {
  for(int j=0;j<q;j++)
  {
   scanf("%d",(*(ptr+i)+j));
  } 
 }
 
 //first 2D M output
 for(int i=0;i<p;i++)
 {
  for(int j=0;j<q;j++)
  {
   printf("%d\t",*(*(ptr+i)+j));
  } 
  printf("\n");
 }
 
 //transpose of initial M
 transpose(p,q,ptr);
 
 //reading x & y
 printf("enter x and y:\n");
 scanf("%d %d",&x,&y);
 ptr=(int**)realloc(ptr,(p+x)*sizeof(int*));
 for(int m=0;m<p+x;m++)
 {
  ptr[m]=(int*)realloc(ptr[m],(y+q)*sizeof(int));
 }
 
 //reading rest of the values
 ptr=change_dimension(p,q,x,y,ptr);
 
 
 //printing final M
 printf("final M matrix:\n");
 for(int i=0;i<(x+p);i++)
 {
  for(int j=0;j<(y+q);j++)
  {
   printf("%d\t",ptr[i][j]);
   //calculating sum of the elements
   sum+=ptr[i][j];
  } 
  printf("\n");
 }
 printf("sum=%d\n",sum);
 //free the pointer ptr
 free(ptr);
 return 0;
}
