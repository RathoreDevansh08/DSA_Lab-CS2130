#include<stdio.h>

int main()
{
 int a[] = {1,2,3,4,5};
 printf("%ld\n",sizeof(a)/sizeof(int));
 return 0;
}
