#include<stdio.h>
#include<stdlib.h>
#include<string.h>   //importing important libraries

int Size=0;  //initializing size of queue as a global variable
typedef struct node //defining a structure for graph node
{
 int data;
 struct node *next;
}node;

typedef struct Qnode //defining a structure for queue node
{
 int key;
 struct Qnode *next;
}Qnode;

typedef struct graph //defining a structure for graph 
{
 node**ll;
 int *dis,*vis,*par;
 int nv;
}graph;

typedef struct queue //defining a structure for queue
{
 Qnode *front,*end; //pointers for pointing front and end
}queue;

Qnode* createQnode(int k) //function to initialize a queue node and return it
{
 Qnode* q=(Qnode*)malloc(sizeof(Qnode)); //declaring a malloc element for queue node
 q->next=NULL;
 q->key=k;
 return q;
}

node* createNode(int k) //function to initialize a graph node and return it
{
 node *a = (node*)malloc(sizeof(node));//declaring a malloc element for graph node
 a->next=NULL;
 a->data=k;
 return a;
}

queue* createQueue() //function to initialize a queue and return it
{
 queue* q=(queue*)malloc(sizeof(queue));//declaring a malloc element for queue
 q->front=q->end=NULL; //pointing front and end to NULL in the beginning
 return q;
}

void enqueue(queue* q,int k) //function to enter elements in the queue 
{
Qnode *t=createQnode(k); //creating a new queue node
 
 if(Size==0) //if queue is empty
 {
   q->end=t;
  t->next=q->end; //declaring new element as front as well as end element
  q->front=q->end;
  Size++; //increasing size
  return ;
 }
 Size++;
 q->end->next=t; //adding it to the next of end pointer
 q->end=t; //changing end pointer
}

int deQueue(queue *q) //function to delete an element from the queue and returning its value
{
 if(Size==0) //underflow condition
 {
  return -1;
 }
 Size--; //decreasing size
 int t=q->front->key; //saving value
 q->front=q->front->next; //moving front to its next
 return t; 
}

Graph* createGraph(int h) //funcion to create a new graph
{
 Graph* temp = (Graph*)malloc(sizeof(Graph)); //initialising it with malloc and typecasting to Graph*
 temp->ll=(node**)malloc(h*sizeof(node*)); //initialising linkedlist with size of #v *sizeof(node*)
 temp->vis= (int*)malloc(h*sizeof(int));  //initialising visited with size of #v *sizeof(int)
 temp->par= (int*)malloc(h*sizeof(int));  //initialising parent with size of #v *sizeof(int)
 temp->sti= (int*)malloc(h*sizeof(int));//initialising starting time with size of #v *sizeof(int)
 temp->fti= (int*)malloc(h*sizeof(int));//initialising ending time with size of #v *sizeof(int)
 temp->nv=h;
 for(int i=0;i<h;i++) //loop to initialize the value of each object
 {
  temp->ll[i]=createNode(i); //initializing each first node to the data vertex
  temp->vis[i]=0; //intialising vertex to be not visited
  temp->par[i]=-1; //initialising parens to be none
  temp->sti[i]=0; //intialising starting and ending time to zero
  temp->fti[i]=0;
 }
 return temp; //time complexity=O(nv)
}

void addEdge(Graph* graph,int u,int v) //function to add edge to graph/adjlist
{
 node* t =createNode(v); //making a new node
 node* temp = graph->ll[u]; //intitiallising temp node to uth linkedlist
 while(temp->next!=NULL && temp->next->data<v)//iterating to find place in list according to index
 {
  temp=temp->next;
 }
 if(temp->next!=NULL) //placing new node in between the previous list
 {t->next=temp->next;}

 temp->next=t;  //worst time complexity=O(nv)
}

int g1[100],g2[100],k=0,l=0;

void bfs(graph *G,int x) //function for breadth first search
{
 queue *q=createQueue(x); //creating a new queue for index x
 enqueue(q,x);  //insertinf the vertex itself in the queue
 G->dis[x]=0; //making distance of x to x zero
 while(Size!=0) //iterating until queue becomes empty
 {
  int u=deQueue(q); //removing first element from queue
  node *temp=G->ll[u]; //assigning *temp to linkedlist of uth vertex
  while(temp->next!=NULL) //going to all its connections
  {
   temp=temp->next;
   if(G->dis[temp->data]==-1) //if not visited condition so as to ensure that vertex is its decendent
   {
    enqueue(q,temp->data); //adding element into the queue
    g1[k]=u;
    g2[k]=temp->data;k++;
    G->dis[temp->data]=G->dis[u]+1; //distance equation
   }
  }
 }  //worst time complexity = O(n)
}

int main()
{
 char line[128];
 int v1,v2,m=-1,n;
 graph *G;           //declaring a graph G
 while(fgets(line, sizeof line, stdin)!=NULL)
 {
  m++;
  if(m==0)
  {
   sscanf(line, "%d",&v1);
   n=v1;
   G=createGraph(n);  //creating/initializing graph G
   continue;
  }
  sscanf(line, "%d %d",&v1,&v2);
  addEdge(G,v1,v2);  //adding edges to graph G 
 }
 bfs(G,0); //bfs for vertex 0
 
 for(int i=0;i<k;i++)  //sorting the tree edges according to th problem statement condition
 {
  for(int j=i+1;j<k;j++)
  {
   if(g1[i]==g1[j])
   {
    if(g2[i]>g2[j])
    {
     l=g2[i];g2[i]=g2[j];g2[j]=l;
    }
   }
   if(g1[i]>g1[j])
   {
    l=g1[i];g1[i]=g1[j];g1[j]=l;
    l=g2[i];g2[i]=g2[j];g2[j]=l;
   }
  }  
  printf("(%d,%d)\n",g1[i],g2[i]); //printing the connections
 }
 
 return 0;
}
