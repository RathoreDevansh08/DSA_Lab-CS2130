#include<stdio.h>     //importing important libraries
#include<string.h>
#include<stdlib.h>

typedef struct node  //structure for basic node or element of a adjecency linked list
{
 int data;           //the vertex value as the data
 struct node *next;
}node;

typedef struct Graph  //structure for basic graph
{
 int nv;          //object to store Number of Vertices
 int *par,*vis,*sti,*fti; //*par: parent index, *vis: visiterd or not, *sti & vti: starting & ending time 
node **ll;      //to store linked list
}Graph;

Graph *graph;

node* createNode(int ver) //function to create a new node
{
 node *newNode=(node*)malloc(sizeof(node)); //declaring new node, a malloc
 newNode->next=NULL; //initializing next pointer to null
 newNode->data=ver;
 return newNode;    
}

Graph* createGraph(int h) //funcion to create a new graph
{
 Graph* temp = (Graph*)malloc(sizeof(Graph)); //initialising it with malloc and typecasting to Graph*
 temp->ll=(node**)malloc(h*sizeof(node*)); //initialising linkedlist with size of #v *sizeof(node*)
 temp->vis= (int*)malloc(h*sizeof(int));  //initialising visited with size of #v *sizeof(int)
 temp->par= (int*)malloc(h*sizeof(int));  //initialising parent with size of #v *sizeof(int)
 temp->sti= (int*)malloc(h*sizeof(int));//initialising starting time with size of #v *sizeof(int)
 temp->fti= (int*)malloc(h*sizeof(int));//initialising ending time with size of #v *sizeof(int)
 temp->nv=h;
 for(int i=0;i<h;i++) //loop to initialize the value of each object
 {
  temp->ll[i]=createNode(i); //initializing each first node to the data vertex
  temp->vis[i]=0; //intialising vertex to be not visited
  temp->par[i]=-1; //initialising parens to be none
  temp->sti[i]=0; //intialising starting and ending time to zero
  temp->fti[i]=0;
 }
 return temp; //time complexity=O(nv)
}

void addEdge(Graph* graph,int u,int v) //function to add edge to graph/adjlist
{
 node* t =createNode(v); //making a new node
 node* temp = graph->ll[u]; //intitiallising temp node to uth linkedlist
 while(temp->next!=NULL && temp->next->data<v)//iterating to find place in list according to index
 {
  temp=temp->next;
 }
 if(temp->next!=NULL) //placing new node in between the previous list
 {t->next=temp->next;}

 temp->next=t;  //worst time complexity=O(nv)
}

int timen=1;

void explore(Graph* graph,int u) //function to explore each link from u
{
 graph->vis[u]=1; //making u as visited
 node *temp=graph->ll[u]; //intialising temp to uth linkedlist
 //printf("%d$",u);
 graph->sti[u]=timen;timen++;//setting starting time
 
 while(temp->next!=NULL) //while it reaches each of u's connections
 {
 	temp=temp->next;
  if(graph->vis[temp->data]==0) //if not visited, exploring the vth vertex
  {
   graph->par[temp->data]=u; //declaring u as parent of v
   explore(graph,temp->data); //exploring v
  }
 }   
    graph->fti[u]=timen;timen++; //setting ending time of vertex u
}  //worst time complexity=O(n^2)


void explore1(Graph* graph,int u) //function to explore each link from u
{
 graph->vis[u]=1; //making u as visited
 node *temp=graph->ll[u]; //intialising temp to uth linkedlist
 printf("%d$",u);
 graph->sti[u]=timen;timen++;//setting starting time
 
 while(temp->next!=NULL) //while it reaches each of u's connections
 {
 	temp=temp->next;
  if(graph->vis[temp->data]==0) //if not visited, exploring the vth vertex
  {
   graph->par[temp->data]=u; //declaring u as parent of v
   explore1(graph,temp->data); //exploring v
  }
 }   
    graph->fti[u]=timen;timen++; //setting ending time of vertex u
}  //worst time complexity=O(n^2)


void dfs(Graph *graph) //function to run dfs
{
 for(int i=0;i<graph->nv;i++) //ierating over all the vertices
 {
  if(graph->vis[i]==0) //checking if its already visited or not
  {
   explore(graph,i);//exploring vertex
  }
 }   //time complexity =O(m+n)
}

int main()
{
 char line[128];
 
 int v1,v2;
 int n,m=-1;
 int j;
 
 Graph *graph, *g;    //intialising graph and the reverse graph
 while(fgets(line, sizeof line, stdin)!=NULL)
 {
  m++;
  if(m==0)
  {
   sscanf(line,"%d",&v1);
   n=v1;
   graph=createGraph(v1);   //creating graph
   g=createGraph(v1);       //creating reverse graph
   continue;
  }else{
  sscanf(line,"%d %d",&v1,&v2);
  addEdge(graph,v1,v2);  //adding edges to the graph
  addEdge(g,v2,v1);      //adding edges to the reverse graph
 }}
 dfs(graph); //dfs function call for the original graph
 
 int a[n],t,b[n];
 for(int i=0;i<n;i++)
 {
  a[i]=graph->fti[i];  //storing initial postvisit or final time in an array
  b[i]=i;
 }
 for(int i=0;i<n;i++)
 {
  for(int j=i+1;j<n;j++)
  {
   if(a[i]<a[j])    //sorting final time array in decreasing order
   {
    t=a[i];a[i]=a[j];a[j]=t;
    t=b[i];b[i]=b[j];b[j]=t;
   }
  }
  if(g->vis[i]==0)                 //if a vertex is yet not visited then exploring it
  {explore1(g,b[i]);printf("\n");} 
 }
 
return 0;
}
