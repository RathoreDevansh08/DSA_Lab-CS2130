#include<stdio.h>
#include<stdlib.h>

typedef struct stack
{
 int data;
 struct stack* next;
}stack;

int size=0;
stack* top;

void push(int key)
{
 if(size==0)
 {
  top = (stack *)malloc(sizeof(stack));
  top->data=key;
  size++;
 }
 else
 {
  stack* temp = (stack *)malloc(sizeof(stack));
  temp->data=key;
  temp->next=top;
  top=temp;
  
  size++;
 }
}

void pop()
{
 stack* temp ;
 temp=top;
 top=top->next;
 free(temp);
 size--;
}

void print()
{
 int y=size;
 stack* to = (stack *)malloc(sizeof(stack));
 to=top;
 
 while(y--) 
 {
  printf("%d\n",to->data);
  to=to->next;
 } 
 free(to);
}

int main()
{
push(10);push(9);push(8);push(7);push(6);pop();pop();pop();
print();
return 0;
}
