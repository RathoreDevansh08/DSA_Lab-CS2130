#include <stdio.h>         
#include <stdlib.h>
#include <string.h>


int stoi(char *str)
{
    int x;
    sscanf(str, "%d", &x);
    return x;
}

int aSizep=0,aSizen=0,topp=-1,topn=-1,msp,msn;    

int pushp(int A[],int key)   
{
 if(msp==aSizep) return -1;   
 aSizep++;                
 A[aSizep-1]=key;
 topp++;
 return 1;            
}
int pushn(int B[],int key)   
{
 if(msn==aSizen) return -1;   
 aSizen++;                 
 B[aSizen-1]=key;
 topn++;
 return 1;           
}

int popP(int A[])          
{
 if(topp==-1) return -1;   
 int lastp=A[aSizep-1];     
 topp--;
 aSizep--;                 
 return lastp;           
}
int popN(int B[])         
{
 if(topn==-1) return 0;  
 int lastn=B[aSizen-1];     
 topn--;
 aSizen--;            
 return lastn;        
}


void printp(int A[])     
{
    for(int i=topp;i>=0;i--)
    {
     printf("%d\n",A[i]);
    }
}   
void printn(int B[])     
{
   
    for(int i=topn;i>=0;i--)
    {
     printf("%d\n",B[i]);
    }
}   

int main (int argc, char **argv)
{
    char line[128];
    char v1[15];
    char v2[15];
    char v3[15];

    int *A = NULL;int *B = NULL;
    int ret;
    int lineNo = 0;

    while (fgets(line, sizeof line, stdin) != NULL )
    {
        sscanf(line, "%s %s %s", v1, v2, v3);
        lineNo++;

        if(lineNo == 1)
        {
            A = (int*) malloc(sizeof(int)* stoi(v1));
            msp=stoi(v1);
            continue;
        }
        if(lineNo == 2)
        {
            B = (int*) malloc(sizeof(int)* stoi(v1));
            msn=stoi(v1);
            continue;
        }
        if(strcmp(v1,"PSH") == 0)
        {
            if(stoi(v2)>=0)
            {
             ret = pushp(A, stoi(v2));
            if(ret < 0)
                printf("%d\n", -1);
            }
            else
            {
             ret = pushn(B, stoi(v2));
            if(ret < 0)
                printf("%d\n", -1);
            }
            
        }
        else if(strcmp(v1,"POPN") == 0)
        {
            ret = popN(B);
                printf("%d\n",ret);
        }
        else if(strcmp(v1,"POPP") == 0)
        {
            ret = popP(A);
                printf("%d\n",ret);
        }
        else if(strcmp(v1,"PRTN") == 0)
        {
            printn(B);
        }
        
        else if(strcmp(v1,"PRTP") == 0)
        {
            printp(A);
        }
        else
        {
            printf("INVALID\n");
        }
    }

    if(A)
        free(A);

    return 0;
}
