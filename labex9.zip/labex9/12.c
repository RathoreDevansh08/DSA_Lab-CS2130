#include<stdio.h>
#include<stdlib.h>
#include<string.h>   //importing important libraries


int left(int i) //function to return the index of left child node
{
 return 2*i+1;
}
int right(int i) //function to return the index of the right child node
{
 return 2*i+2;
}

void in(int a[],int i,int n) //function for inorder traversal
{
 if(i>=n)return; //terminating condition
 in(a,left(i),n); //recursive function call for the left child node
 printf("%d ",a[i]); //printing the value
 in(a,right(i),n); //recursive function call for the right child node
 return;
} //time complexity= O(n)

void pr(int a[],int i,int n) //function for preorder traversal
{
 if(i>=n)return; //terminating condition
 printf("%d ",a[i]); //printing the value
 pr(a,left(i),n); //recursive function call for the left child node
 pr(a,right(i),n); //recursive function call for the right child node
 return; //time complexity= O(n)
}

void po(int a[],int i,int n) //function for preorder traversal
{
 if(i>=n)return; //terminating condition
 po(a,left(i),n); //recursive function call for the left child node
 po(a,right(i),n); //recursive function call for the right child node
 printf("%d ",a[i]); //printing the value
 return;
}  //time complexity= O(n)

int main()
{
 char line[128];
 int n;
 
 scanf("%d",&n); //scanning #nodes
 int a[n];
 scanf("%d",&a[0]); //scanning the root element

for(int i=1;i<n;i++) //scanning rest of the elements
{
  scanf("%d",&a[i]);
}

in(a,0,n);printf("\n"); //function calls for the traversals
pr(a,0,n);printf("\n");
po(a,0,n);printf("\n"); 
 
 return 0;
}
