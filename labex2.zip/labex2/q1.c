#include<stdio.h>
#include<stdlib.h>

void shift(int A[],int n)
{
 int temp,temp2,j;
 for(j=0;j<(n);j++)
 {
  if(A[j]>A[n-1])
  {
   temp=A[j];
   A[j]=A[n-1];
   break;
  }
 }
 
 temp2=A[j+1];
 A[j+1]=temp;
 
 for(int k=j+2;k<n;k++)
 {
  temp=A[k];
  A[k]=temp2;
  temp2=temp;
 }
 
 for(int k=0;k<n;k++)
 {
  printf("%d\n",A[k]);
 }
 return;
}
int main()
{
 int n;
 printf("enter the number of elements in required format:\n");
 scanf("%d",&n);
 
 int A[n], *p;
 for(int i=0;i<n;i++)
 {
  scanf("%d",&A[i]);
 }
 
 shift(A,n);
 
 return 0;
}
