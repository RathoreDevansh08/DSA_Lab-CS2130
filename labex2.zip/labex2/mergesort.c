#include<stdio.h>

int* mergesort(int* p)
{
 int n1=
 
 return p;
}

int main()
{
 int a[]={2,4,7,1,5,9,0,8,3,6};
 int *p;
 p=a;
 p=mergesort(p);
 
 for(int i=0;i<10;i++)
 printf("%d\n",*(p+i));
}
