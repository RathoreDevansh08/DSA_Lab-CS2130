#include <stdio.h>                 //import important libraries
#include <stdlib.h>
#include <string.h>

//Code to parse integer from a string
int stoi(char *str)
{
    int x;
    sscanf(str, "%d", &x);
    return x;
}

int aSize=0,front=-1,rear=-1,ms;    // initialising the variables : queue size, front to -1, maximum size 


int enqueue(int A[],int key)   //function to add the element in the queue
{
 if(aSize==ms) return -1;      //checking if the queue is not already filled
 
 if(rear==ms-1)                //for the circular queue, taking the rear to index 0 if 
 {                             //initial indices of queue (array) are vacant
  rear=-1;
 }
 rear++;                        //increasing size of the queue
 aSize++;
 A[rear]=key;                   //inserting key value at the rear position
 return 1;                      //time complexity=O(1)
}

int dequeue(int A[])           //function to delete the element in the queue
{
 int last;
 if(aSize==0) return -1;        //checking if the queue is not already empty
 last=A[front+1];                 //entering last element
 front++;                         //increasing frint index, decreasing size
 aSize--;
 return last;                   //time complexity = O(1), constant space complexity
}

int peekFront(int A[])
{
 if(aSize==0) return -1;       //function to return the front if existing
 
 return A[front+1];
}

void print(int A[])         //function to print the elements of the queue
{
    /* Display the heap represented by A in the increasing order
    of their indices, one element per line.*/
    if(aSize!=0 && rear<=front)            //condition for rear index is lesser than front element
    {
     for(int i=front+1;i<=ms-1;i++)
     {
      printf("%d\n",A[i]);
     }
     for(int i=0;i<=rear;i++)
     {
      printf("%d\n",A[i]);
     }
    }
    
    else                                  //condition for front index is lesser than rear element
    {
     for(int i=front+1;i<=rear;i++)
     {
      printf("%d\n",A[i]);
     }
    }
}

int size(int A[])
{
 return aSize;                      //function to print the size of the queue
}

int isEmpty(int A[])
{
 if(aSize==0) return 1;            //function to check if the queue is empty or not
 return 0;
}

int isFull(int A[])
{
 if(aSize==ms) return 1;           //function to check if the queue is full or not
 return 0;
}

int main (int argc, char **argv)
{
    char line[128];
    char v1[15];
    char v2[15];
    char v3[15];

    int *A = NULL;
    int ret;
    int lineNo = 0;

    while (fgets(line, sizeof line, stdin) != NULL )
    {
        sscanf(line, "%s %s %s", v1, v2, v3);
        lineNo++;

        if(lineNo == 1)
        {
            A = (int*) malloc(sizeof(int)* stoi(v1));
            ms=stoi(v1)-1;                            //for allowing maximum permissible number of elements in queue as one less than the given value
            continue;
        }

        if(strcmp(v1,"ENQ") == 0)
        {
            ret = enqueue(A, stoi(v2));
            if(ret < 0)
                printf("%d\n", -1);
        }
        else if(strcmp(v1,"DEQ") == 0)
        {
            ret = dequeue(A);
                printf("%d\n",ret);
        }
        else if(strcmp(v1,"FRN") == 0)
        {
            ret = peekFront(A);
            if(ret ==-1)
                printf("%d\n", -1);
            printf("%d\n",ret);    
        }
        else if(strcmp(v1,"PRT") == 0)
        {
            print(A);
        }
        else if(strcmp(v1,"SZE") == 0)
        {
            ret = size(A);
            printf("%d\n",ret);
        }
        else if(strcmp(v1,"EMP") == 0)
        {
            ret = isEmpty(A);
            printf("%d\n",ret);
        }
        else if(strcmp(v1,"FUL") == 0)
        {
            ret = isFull(A);
            printf("%d\n",ret);
        }
        else
        {
            printf("INVALID\n");
        }
    }

    if(A)
        free(A);

    return 0;
}
