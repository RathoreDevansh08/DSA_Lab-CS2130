#include <stdio.h>         //include all important libraries 
#include <stdlib.h>
#include <string.h>

//Code to parse integer from a string
int stoi(char *str)
{
    int x;
    sscanf(str, "%d", &x);
    return x;
}

int aSize=0,top=-1,ms;    //initialising stack size, top to -1, maximum permissible size


int push(int A[],int key)   //function to insert element in the stack
{
 if(ms==aSize) return -1;   //returning if its already filled
 aSize++;                 //increasing the stack size
 A[aSize-1]=key;
 top++;
 return 1;             //time complexity = O(1)
}

int pop(int A[])             //function for deleting top element from the stack
{
 if(top==-1) return -1;    //returning if the stack is already empty(underflow)
 int last=A[aSize-1];      //storing the element to be deleted
 top--;
 aSize--;                  //decreasing the array size
 return last;           //time complexity = O(1)
}

int peek(int A[])         //function to return the element at the top+1 index
{
 if(top==-1) return -1;
 
 return A[top];        //time complexity = O(1)
}

void print(int A[])       //function to print the elements of stack
{
    /* Display the heap represented by A in the increasing order
    of their indices, one element per line.*/
    for(int i=top;i>=0;i--)
    {
     printf("%d\n",A[i]);
    }
}                            //time complexity =  O(n)

int size(int A[])
{
 return aSize;          //function to return the size of the stack
}

int isEmpty(int A[])      //function to check if the stack is empty
{
 if(top==-1) return 1;
 return 0;
}

int isFull(int A[])
{
 if(top==ms) return 1;     //function to check if the stack is full
 return 0;
}

int main (int argc, char **argv)
{
    char line[128];
    char v1[15];
    char v2[15];
    char v3[15];

    int *A = NULL;
    int ret;
    int lineNo = 0;

    while (fgets(line, sizeof line, stdin) != NULL )
    {
        sscanf(line, "%s %s %s", v1, v2, v3);
        lineNo++;

        if(lineNo == 1)
        {
            A = (int*) malloc(sizeof(int)* stoi(v1));
            ms=stoi(v1);
            continue;
        }

        if(strcmp(v1,"PSH") == 0)
        {
            ret = push(A, stoi(v2));
            if(ret < 0)
                printf("%d\n", -1);
        }
        else if(strcmp(v1,"POP") == 0)
        {
            ret = pop(A);
                printf("%d\n",ret);
        }
        else if(strcmp(v1,"TOP") == 0)
        {
            ret = peek(A);
            if(ret ==-1)
                printf("%d\n", -1);
            printf("%d\n",ret);    
        }
        else if(strcmp(v1,"PRT") == 0)
        {
            print(A);
        }
        else if(strcmp(v1,"SZE") == 0)
        {
            ret = size(A);
            printf("%d\n",ret);
        }
        else if(strcmp(v1,"EMP") == 0)
        {
            ret = isEmpty(A);
            printf("%d\n",ret);
        }
        else if(strcmp(v1,"FUL") == 0)
        {
            ret = isFull(A);
            printf("%d\n",ret);
        }
        else
        {
            printf("INVALID\n");
        }
    }

    if(A)
        free(A);

    return 0;
}
